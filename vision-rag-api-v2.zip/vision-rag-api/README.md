# HomeRepairBot — Vision + Language Multi-Turn Repair Assistant  
**Author:** Manuel “Manny” Buffa  
**Status:** Prototype v1 (Multi-Turn + Vision Working)  
**License:** GPL-3.0-or-later

HomeRepairBot is an end-to-end system for providing **step-by-step home-repair guidance** through a combination of:

- **FastAPI backend**
- **Qwen2.0-VL-2B Instruct** for vision + text reasoning
- **CLIP embeddings + FAISS** for image-aware retrieval
- **Google Programmable Search Engine (CSE)** for external reference lookups
- **Android frontend** for capturing queries and images, and displaying multi-turn guidance

The system supports:

- 🔍 First-turn repair plan generation using search, summary synthesis, and structured LLM output  
- 🔁 Multi-turn follow-ups with rolling dialog memory  
- 🧠 Hazard detection + intent gating  
- 📸 Image captioning + similarity retrieval  
- 📂 On-disk session logging (events, summary, memory)

This is the submission package for the project hand-off.

---

## Features

### ✔ First-Turn Repair Plan Generation  
On a new dialog, the backend performs:

1. Image captioning (if provided)  
2. Web/image/document retrieval  
3. Multi-document synthesis  
4. LLM plan generation with structured sections:
   - Overview  
   - Tools you’ll need  
   - First step

### ✔ Multi-Turn Step-by-Step Guidance  
Subsequent user messages call a compact frontend/backed pipeline:

- State + memory load  
- Rolling context summarization  
- “Next-step” model call  
- Follow-up question generation (if appropriate)

### ✔ Android Frontend  
- Captures text + image queries  
- Displays structured repair plans  
- Supports multi-turn conversations  
- Provides debug tools (long-press API/state inspection)

---

## Installation

### Backend (FastAPI)
backend/
main.py
orchestrator/
fusion.py
synthesis.py
safety.py
session_utils.py
qwen_use.py
rag/
clip_encode.py
faiss_store.py
data/
whitelist_urls.txt
sessions/
android_app/
app/src/main/java/com/diy_ai/homerepairbot/
MainActivity.kt
Repository.kt
SessionStore.kt
ui helpers…
res/layout/activity_main.xml
docs/
Report.md
---

## Known Issues / Future Work

- **LLM Prompt + Parameter Tuning Needed**  
  Users may occasionally see:
  - Section misalignment (e.g., Overview where First Step should be)  
  - Wrong heading ordering  
  - Occasional plan drift  
  These issues require systematic tuning of system prompts + temperature.

- **Better Multi-Turn Guardrails**  
  Multi-turn works, but needs refinement:
  - Hazard summaries could be more consistent  
  - Topic boundaries could be enforced more strictly  
  - Intent gating may occasionally misfire on follow-ups

- **Frontend Tidying**  
  - Plan card spacing + typography can be cleaned up  
  - "Copy All" long-press behavior may need polish  
  - Some early turn-switch UI clearing behaviors can be improved

- **Search Retrieval Quality**  
  Search → synthesis chain functions, but performance and noise-reduction can be tuned.

---
## License

Distributed under the **GPL-3.0-or-later** open-source license.  
See **LICENSE** for details.

---

## Acknowledgements

This project uses:

- Qwen2.0-VL-2B (Alibaba)  
- OpenAI CLIP  
- FAISS  
- FastAPI  
- Android Jetpack  

And a large amount of custom orchestrator logic developed specifically for this project.