#!/usr/bin/env bash
set -euo pipefail

pids_by_port() {
  local port="$1"
  # Try lsof first (most reliable)
  if command -v lsof >/dev/null 2>&1; then
    lsof -i TCP:"$port" -sTCP:LISTEN -t 2>/dev/null || true
    return
  fi
  # Fallback to ss (BusyBox-safe parsing)
  ss -ltnp 2>/dev/null | awk -v pat=":$port" '
    $4 ~ pat {
      match($6, /pid=([0-9]+)/, m);
      if (m[1] != "") print m[1];
    }' | sort -u || true
}

kill_port() {
  local port="$1"
  while read -r pid; do
    [ -n "${pid:-}" ] || continue
    if ps -p "$pid" -o comm= | grep -qi 'python'; then
      echo "Killing PID $pid on port $port"
      kill -TERM "$pid" 2>/dev/null || true
      sleep 0.5
      kill -KILL "$pid" 2>/dev/null || true
    fi
  done < <(pids_by_port "$port")
}

kill_uvicorn_matches() {
  pgrep -f "uvicorn.*app.main:app" 2>/dev/null | xargs -r -I{} sh -c '
    echo "Killing uvicorn PID {}"; kill -TERM {} || true; sleep 0.5; kill -KILL {} || true'
}

kill_port 8000
kill_port 8001
kill_uvicorn_matches

echo "Ports 8000/8001 cleared (if any)."
ss -ltnp | grep -E ':8000|:8001' || echo "No listeners on 8000/8001."
