#!/usr/bin/env python
"""
Simple CLI tool to test web search + whitelist behavior.

Usage:
  python scripts/test_web_search.py "kitchen faucet drips after shutoff"

It:
  - Resolves the whitelist file path from settings
  - Loads allowed domains (including whitelist_urls.txt)
  - Runs google_search_text() with those domains
  - Prints each result's domain, title, and URL
"""

import sys
from pathlib import Path

from app.core.settings import settings
from app.utils.search_utils import (
    load_whitelists,
    google_search_text,
    normalize_domain,
)

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python scripts/test_web_search.py \"your query here\"")
        sys.exit(1)

    query = sys.argv[1]
    print(f"\n=== Testing web search for query: {query!r} ===\n")

    # ------------------------------------------------------------------ #
    # 1) Resolve whitelist path and load domains
    # ------------------------------------------------------------------ #
    wl_path_str = settings.resolved_whitelist_path() or settings.whitelist_urls_path
    wl_path = Path(wl_path_str)

    print(f"[test] resolved whitelist path: {wl_path}")
    if not wl_path.exists():
        print("[test] WARNING: whitelist file does not exist!")
    else:
        print("[test] whitelist file exists ✓")

    # Use defaults from settings + file contents
    allowed_domains, _repos = load_whitelists(
        wl_path,
        defaults_domains=settings.allowed_domains,
        defaults_repos=settings.allowed_repos,
    )

    print(f"[test] allowed_domains ({len(allowed_domains)}):")
    for d in allowed_domains:
        print(f"  - {d}")
    print()

    # ------------------------------------------------------------------ #
    # 2) Ensure Google CSE config is present
    # ------------------------------------------------------------------ #
    api_key = settings.google_api_key
    cx = settings.google_text_cse_id

    if not api_key or not cx:
        print(
            "[test] ERROR: GOOGLE_API_KEY and/or GOOGLE_TEXT_CSE_ID "
            "are not set in settings/env."
        )
        print(f"  google_api_key set? {bool(api_key)}")
        print(f"  google_text_cse_id set? {bool(cx)}")
        sys.exit(1)

    print("[test] GOOGLE_API_KEY and GOOGLE_TEXT_CSE_ID found ✓\n")

    # ------------------------------------------------------------------ #
    # 3) Run google_search_text with strict whitelist
    # ------------------------------------------------------------------ #
    print("[test] calling google_search_text(...)")
    results = google_search_text(
        query=query,
        api_key=api_key,
        cx=cx,
        allowed_domains=allowed_domains,
        max_results=10,
    )

    if not results:
        print("\n[test] No results returned (empty list).")
        sys.exit(0)

    # ------------------------------------------------------------------ #
    # 4) Print results with domains for inspection
    # ------------------------------------------------------------------ #
    print(f"\n[test] got {len(results)} result(s):\n")
    for idx, r in enumerate(results, start=1):
        url = getattr(r, "url", None) or r.url  # SearchResult has .url
        title = getattr(r, "title", None) or r.title
        snippet = getattr(r, "snippet", None) or r.snippet
        dom = normalize_domain(url)

        # FIX: Precompute the cleaned snippet (no backslashes inside f-string expression)
        clean_snip = (snippet or "").replace("\n", " ")[:200]

        print(f"[{idx}] domain: {dom}")
        print(f"    title : {title}")
        print(f"    url   : {url}")
        print(f"    snippet: {clean_snip}")
        print()
    print("[test] done.\n")


if __name__ == "__main__":
    main()
