# scripts/debug_qwen_queries.py

import json
import sys
from typing import Optional

# Ensure app/ is importable when running from repo root
# (You already do similar in other scripts; adjust if needed)
if __name__ == "__main__" and __package__ is None:
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app.services.qwen_use import generate_queries_llm  # type: ignore


def main() -> None:
    if len(sys.argv) < 2:
        print(
            "Usage: python scripts/debug_qwen_queries.py "
            "'<user text>' ['<image caption>']"
        )
        sys.exit(1)

    user_text = sys.argv[1]
    caption: Optional[str] = sys.argv[2] if len(sys.argv) >= 3 else None

    print("=== INPUT ===")
    print(f"user_text : {user_text!r}")
    print(f"caption   : {caption!r}")
    print()

    queries = generate_queries_llm(user_text, caption, prefer_rag=True, max_queries=6)

    print("=== OUTPUT QUERIES ===")
    print(json.dumps(queries, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
