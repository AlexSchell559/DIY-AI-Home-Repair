#!/usr/bin/env python3
"""
Quick probe for app.services.qwen_use.infer_topic_intent

Run from project root:

    python scripts/qwen_probe_topic_intent.py
"""

import json
import sys
from pathlib import Path

# Ensure project root is on sys.path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.qwen_use import infer_topic_intent  # type: ignore[import]


def run_case(label: str, user_text: str, caption: str | None = None):
    print("=" * 80)
    print(f"CASE: {label}")
    print(f"USER TEXT: {user_text!r}")
    if caption:
        print(f"CAPTION: {caption!r}")
    print("-" * 80)
    res = infer_topic_intent(user_text=user_text, caption=caption)
    print(json.dumps(res, indent=2))
    print()


def main():
    cases = [
        (
            "kitchen faucet leak",
            "My kitchen faucet is leaking under the sink and water is pooling in the cabinet.",
            None,
        ),
        (
            "breaker trips with microwave",
            "Every time I run the microwave, the kitchen breaker trips after about 30 seconds.",
            None,
        ),
        (
            "drywall crack in ceiling",
            "There is a long crack in my living room ceiling that keeps getting wider.",
            None,
        ),
        (
            "fantasy novel (non-repair)",
            "Can you help me outline a fantasy novel about dragons and magic kingdoms?",
            None,
        ),
        (
            "pet photo (non-repair)",
            "How do I fix this? Caption: a tabby cat laying on a bed with pillows.",
            "a tabby cat laying on a bed with pillows",
        ),
        (
            "gas line replacement (hazard but NOT emergency)",
            "I'm replacing the gas line to my stove in the kitchen. The gas is currently shut off at the main.",
            None,
        ),
        (
            "strong gas smell (emergency scenario text)",
            "I smell a strong gas odor in my kitchen near the stove and I don't know where it's coming from.",
            None,
        ),
        (
            "kitchen fire (emergency scenario text)",
            "There are flames coming from the pan on my stove and the fire is starting to spread.",
            None,
        ),
    ]

    for label, text, cap in cases:
        run_case(label, text, cap)


if __name__ == "__main__":
    main()
