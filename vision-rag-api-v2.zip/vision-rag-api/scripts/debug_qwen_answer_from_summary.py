#!/usr/bin/env python3
"""
Quick probe for app.services.qwen_use.answer_from_summary_llm

Run from project root:

    python scripts/debug_qwen_answer_from_summary.py
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.qwen_use import (
    summarize_longform_llm,
    answer_from_summary_llm,
)  # type: ignore[import]


def build_demo_longform_pack():
    # Same style as debug_qwen_summary.py
    return {
        "longform": {
            "text": [
                {
                "source": "manual",
                "snippet": (
                    "Turn off the water supply to the faucet using the shutoff "
                    "valves under the sink. Place a bucket or towel in the cabinet "
                    "to catch any remaining water. Loosen the nuts on the supply "
                    "lines with an adjustable wrench."
                ),
                },
                {
                "source": "manual",
                "snippet": (
                    "Inspect the faucet cartridge or valve stem for wear. Replace "
                    "the cartridge with a matching part from the manufacturer. "
                    'Reassemble the faucet and restore water to test for leaks.'
                ),
                },
            ],
            "web": [
                {
                "source": "web",
                "snippet": (
                    "Dripping kitchen faucets are often caused by worn cartridges "
                    "or O-rings. Shut off water, disassemble the handle, and swap "
                    "in new parts to stop the drip."
                ),
                }
            ],
        },
        "evidence_refs": [],
    }


def main():
    issue_text = (
        "My kitchen faucet is dripping and water is collecting on the bottom of "
        "the cabinet under the sink."
    )

    longform_pack = build_demo_longform_pack()

    # 1) Build the summary using the tuned summarizer
    summary = summarize_longform_llm(
        issue_text=issue_text,
        longform_pack=longform_pack,
        topic="plumbing",
        topic_intent={"topic": "plumbing", "intent": "repair"},
        image_caption=None,
        safety={},
        dialog_id="dbg-ans-1",
    )

    print("=" * 80)
    print("SUMMARY TEXT (truncated)")
    print("=" * 80)
    guide = summary.get("text", "")
    print("\n".join(guide.splitlines()[:20]))
    print()
    print("Summary word count:", len(guide.split()))
    print()

    # 2) Build the answer-from-summary
    user_bundle = {
        "user_text": issue_text,
        "topic_intent": {"topic": "plumbing", "intent": "repair"},
        "safety": {},
        "ack_stage": 0,
    }

    sections = answer_from_summary_llm(
        summary=summary,
        history=[],
        user_bundle=user_bundle,
        dialog_id="dbg-ans-1",
    )

    print("=" * 80)
    print("ANSWER SECTIONS")
    print("=" * 80)
    print("Overview:", sections.get("scope_overview"))
    print("Hazards:", sections.get("hazards"))
    print("Tools:", sections.get("tools_required"))
    print("Materials:", sections.get("materials"))
    print("First Step:", sections.get("first_step"))
    print("Next question:", sections.get("next_question"))
    print("Answer preview:", sections.get("answer_preview"))
    print()


if __name__ == "__main__":
    main()
