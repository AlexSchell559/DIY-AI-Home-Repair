#!/usr/bin/env python3
"""
Quick probe for app.services.qwen_use.summarize_longform_llm

Run from project root:

    python scripts/debug_qwen_summary.py
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.qwen_use import summarize_longform_llm  # type: ignore[import]


def main():
    # Simple demo longform pack: one local/manual passage + one web passage
    longform_pack = {
        "longform": {
            "text": [
                {
                    "source": "manual",
                    "snippet": (
                        "Turn off the water supply to the faucet using the shutoff "
                        "valves under the sink. Place a bucket or towel in the cabinet "
                        "to catch any remaining water. Loosen the nuts on the supply "
                        "lines with an adjustable wrench."
                    ),
                },
                {
                    "source": "manual",
                    "snippet": (
                        "Inspect the faucet cartridge or valve stem for wear. Replace "
                        "the cartridge with a matching part from the manufacturer. "
                        "Reassemble the faucet and restore water to test for leaks."
                    ),
                },
            ],
            "web": [
                {
                    "source": "web",
                    "snippet": (
                        "Dripping kitchen faucets are often caused by worn cartridges "
                        "or O-rings. Shut off water, disassemble the handle, and swap "
                        "in new parts to stop the drip."
                    ),
                }
            ],
        },
        "evidence_refs": [],
    }

    issue_text = (
        "My kitchen faucet is dripping and water is collecting on the bottom of "
        "the cabinet under the sink."
    )

    summary = summarize_longform_llm(
        issue_text=issue_text,
        longform_pack=longform_pack,
        topic="plumbing",
        topic_intent={"topic": "plumbing"},
        image_caption=None,
        safety={},
        dialog_id="dbg-sum-1",
    )

    guide = summary.get("text", "")
    print("=" * 80)
    print("SUMMARY TEXT")
    print("=" * 80)
    print(guide)
    print()
    print("Word count:", len(guide.split()))
    print("Topic:", summary.get("topic"))
    print("Dialog ID:", summary.get("dialog_id"))


if __name__ == "__main__":
    main()
