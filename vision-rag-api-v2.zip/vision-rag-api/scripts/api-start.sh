#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# venv + env
source ./.venv/bin/activate
set -a; source ./.env.runtime; set +a
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

# optional: clear old log buffer for your own sanity while testing
: > /tmp/vision-rag-api.out || true

# quick import proof
python - <<'PY'
import os, sys
print("CWD:", os.getcwd())
print("Python:", sys.executable)
import app.main as m
print("import app.main OK; module-level app:", hasattr(m, "app"), " factory:", hasattr(m, "create_app"))
PY

echo "Starting uvicorn FOREGROUND on :8000 (Ctrl+C to stop)…"
./.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload --log-level info
