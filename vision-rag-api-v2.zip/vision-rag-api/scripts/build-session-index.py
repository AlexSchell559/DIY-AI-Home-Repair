#!/usr/bin/env python3
# scripts/build-session-index.py
from __future__ import annotations
import json, re
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
from typing import Any, Dict, List

SESS_ROOT = Path("./data/sessions")

def _safe_glob_events() -> Dict[str, List[Path]]:
    out: Dict[str, List[Path]] = {}
    if not SESS_ROOT.exists():
        return out
    for dlg_dir in SESS_ROOT.iterdir():
        if not dlg_dir.is_dir():
            continue
        evdir = dlg_dir / "events"
        if not evdir.exists():
            continue
        files = sorted(p for p in evdir.glob("*.json") if p.is_file())
        if files:
            out[dlg_dir.name] = files
    return out

def _read_json(p: Path) -> Dict[str, Any] | None:
    try:
        return json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

def _ts(dt: str | None) -> float:
    if not dt:
        return 0.0
    try:
        # payload timestamps look like ISO 8601; tolerate ":" replacement
        return datetime.fromisoformat(dt.replace("Z","").replace(":", ":", 2)).timestamp()
    except Exception:
        return 0.0

_STOP = {
    "a","an","the","and","or","but","if","in","on","at","by","for","to","of","with",
    "about","into","through","from","over","after","before","between","under","without",
    "is","are","was","were","be","been","being","do","does","did","done","doing",
    "it","its","this","that","these","those","as","than","so","such","you","your",
    "can","could","should","would","will","may","might","not","no","yes","ok","okay",
    "i","we","they","he","she","them","us"
}

HAZARD_TOKENS = {"gas","electrical","asbestos","mold","lead","silica","fall","shock","flood","fire","structural"}

def _keywords(text: str, limit=10) -> List[str]:
    text = text.lower()
    words = re.findall(r"[a-z0-9\-]{3,}", text)
    words = [w for w in words if w not in _STOP and not w.isdigit()]
    common = [w for w,_ in Counter(words).most_common(limit)]
    return common

def _coerce_list(x):
    return x if isinstance(x, list) else []

def _flatten_text_parts(payload: Dict[str, Any]) -> str:
    parts: List[str] = []
    q = payload.get("query") or {}
    if q.get("text"): parts.append(str(q.get("text")))
    if payload.get("answer"): parts.append(str(payload["answer"]))
    # include captions or last few evidence titles
    if isinstance(payload.get("evidence"), list):
        for ev in payload["evidence"][:5]:
            if isinstance(ev, dict):
                t = ev.get("title") or ev.get("caption")
                if t: parts.append(str(t))
    return " \n ".join(parts)

def _extract_hazards(payload: Dict[str, Any]) -> List[str]:
    # Prefer structured safety report if present
    safety = payload.get("safety")
    found = set()
    if isinstance(safety, dict):
        # typical shape: {"work_types": {...}, "stop": [...], "caution": [...]}
        for k in ("stop","caution"):
            for h in _coerce_list(safety.get(k)):
                if isinstance(h, str):
                    found.add(h.lower())
    # Fallback: mine warnings + text for hazard tokens
    if not found:
        warns = payload.get("warnings") or []
        for w in _coerce_list(warns):
            w = str(w).lower()
            for token in HAZARD_TOKENS:
                if token in w:
                    found.add(token)
        text = _flatten_text_parts(payload).lower()
        for token in HAZARD_TOKENS:
            if token in text:
                found.add(token)
    return sorted(found)

def _safe_get_ack(payload: Dict[str, Any]) -> int | None:
    # attempt to read ack_stage or intent acknowledgment
    q = payload.get("query") or {}
    if "ack_stage" in q and isinstance(q["ack_stage"], int):
        return q["ack_stage"]
    # sometimes intent decision is persisted
    intent_decision = payload.get("intent_decision")
    if isinstance(intent_decision, dict):
        st = intent_decision.get("ack_stage")
        if isinstance(st, int):
            return st
    return None

def main():
    dialogs = _safe_glob_events()
    index: Dict[str, Any] = {"generated_at": datetime.utcnow().isoformat(timespec="seconds") + "Z", "dialogs": {}}

    for dlg_id, files in dialogs.items():
        created_at = None
        updated_at = None
        num = len(files)
        last_payload = None

        # read latest event
        if files:
            last_payload = _read_json(files[-1])
            # try timestamps from the payload; fallback to filename order
            if isinstance(last_payload, dict):
                updated_at = last_payload.get("timestamp_utc")
        # created_at from the first event payload if available
        first_payload = _read_json(files[0]) if files else None
        if isinstance(first_payload, dict):
            created_at = first_payload.get("timestamp_utc")

        # derive values
        answer_preview = None
        last_ack_stage = None
        hazards: List[str] = []
        recent_keywords: List[str] = []

        if isinstance(last_payload, dict):
            ans = (last_payload.get("answer") or "")[:200].replace("\n", " ").strip()
            answer_preview = ans or None
            last_ack_stage = _safe_get_ack(last_payload)
            hazards = _extract_hazards(last_payload)

        # light keywording from last 5 events
        texts: List[str] = []
        for p in files[-5:]:
            pl = _read_json(p)
            if not isinstance(pl, dict): 
                continue
            texts.append(_flatten_text_parts(pl))
        recent_keywords = _keywords("\n".join(texts), limit=10) if texts else []

        index["dialogs"][dlg_id] = {
            "dialog_id": dlg_id,
            "created_at": created_at,
            "updated_at": updated_at,
            "num_events": num,
            "last_answer_preview": answer_preview,
            "last_ack_stage": last_ack_stage,
            "hazards": hazards,
            "top_keywords": recent_keywords,
        }

    outp = SESS_ROOT / "session_index.json"
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(index, indent=2, ensure_ascii=False))
    print(f"Wrote: {outp} (dialogs={len(index['dialogs'])})")

if __name__ == "__main__":
    main()

