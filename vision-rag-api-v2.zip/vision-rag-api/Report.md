# HomeRepairBot – Technical Report  
**Author:** Manuel Buffa  
**Course:** Graduate AI / Computer Vision / NLP Project  
**Status:** Prototype v1  
**Date:** 2025

---

## 1. Introduction

HomeRepairBot is a vision-language system designed to guide users through DIY home-repair tasks using:
- Natural-language instructions
- Smartphone-captured photos
- Multi-turn conversation memory
- Retrieval-augmented reasoning

It aims to deliver a safe, structured, actionable repair plan without human expert intervention.

---

## 2. System Architecture

### 2.1 Backend Components

**(1) Image Understanding**
- Qwen2.0-VL-2B produces:
  - Image caption  
  - Query grounding  
  - Feature embeddings (via CLIP)  

**(2) Retrieval**
- CLIP embeddings stored in FAISS  
- Google CSE whitelisted search  
- Local doc search  
- Multi-source aggregation  

**(3) Fusion + Synthesis**
- Retrieve → score → long-form consolidation → LLM summarization  
- Outputs structured plan fields:
  - `scope_overview`
  - `tools_required`
  - `first_step`

**(4) Multi-Turn Pipeline**
- Session folders maintain:
  - `latest.json`
  - Prior events  
  - Summaries  
- Context builder constructs:
  - Topic, hazards, latest turn  
  - 3–5 event history  
  - Summary text  

**(5) LLM Answer Functions**
- **answer_from_summary_llm**  
  First-turn plan builder; structured, long-form  
- **generate_next_step_llm (v5)**  
  Short, actionable next step with labeled lines:
  - `Next step:`
  - `Follow-up question:`

---

## 3. Android Frontend

Features:

- Image + text capture  
- Real-time rendering of structured plan cards  
- Multi-turn conversation view  
- Debug tools (state/memory viewer)  
- Local dialog creation (dlg-xxxx hybrid model)

Most processing happens on the backend; the app is a lightweight IO/renderer.

---

## 4. Experiments & Observations

### 4.1 Performance

- Qwen2-VL + RAG consistently identifies topic/hazards.
- Structured plans display well after frontend restructuring.
- Multi-turn next-step reasoning is stable after prompt format enforcement.

### 4.2 Common Issues (v1 Prototype)

- **Section misalignment**:  
  Occasionally the LLM outputs an Overview where First Step should be.  
  → Caused by model’s format drift; requires further prompt optimization.

- **Intent gate false positives**:  
  Follow-up questions (e.g., "What’s next?") sometimes misclassified as non-repair.  
  → Fixable through tuning threshold and refining the classifier prompt.

- **Search retrieval noise**:  
  Some queries pull irrelevant web snippets.  
  → Needs stricter filtering, weighting, or a reranker.

- **Frontend UX rough edges**:  
  - Copy behaviors differ between long-press on text vs card background  
  - Message spacing in conversation stack  
  - Back-scroll behavior in long sessions  

These are cosmetic issues for future refinement.

---

## 5. Future Work

### Short-Term
- Improve prompt consistency using few-shot examples for:
  - structured next-step  
  - summary synthesis  
- Adjust temperature / top-p settings dynamically per step  
- Backend reranker tuning

### Medium-Term
- Add step-by-step visuals via “next-step image search”  
- Provide offline CLIP + retrieval mode (no Google CSE)  
- Improve hazard detection and safety-first planning

### Long-Term
- Larger model options (3B–7B) for richer reasoning  
- Full ML fine-tuning on real repair data  
- Web dashboard for session review  

---

## 6. Conclusion

This prototype demonstrates a fully functioning:
- Vision → retrieval → synthesis → plan core  
- Multi-turn conversational repair guidance  
- Android client integration  
- Safety gating  
- Persistent dialog memory  

The system is production-viable pending:
- prompt stability improvements  
- retrieval tuning  
- frontend polish  

It serves as a foundation for a next-generation AI-powered home-repair assistant.

