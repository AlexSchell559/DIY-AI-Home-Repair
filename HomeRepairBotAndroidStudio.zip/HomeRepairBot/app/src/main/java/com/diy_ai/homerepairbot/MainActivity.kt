package com.diy_ai.homerepairbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory

import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.ByteArrayOutputStream

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.diy_ai.homerepairbot.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // IMPORTANT: Replace with your actual Hugging Face Inference API Key
    private val HF_API_TOKEN = "Bearer YOUR_CUSTOM_OR_HF_TOKEN"

    // The base URL for the Hugging Face Inference API
    private val HF_BASE_URL = "http://192.168.1.10:8080/" // <-- **CHANGE THIS to your host IP and port**
    private val QWEN_MODEL_NAME = "Qwen/Qwen2.5-VL-4B-Instruct" // Model name in the URL path

    private val apiService by lazy {
        Retrofit.Builder()
            .baseUrl(HF_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(HuggingFaceApiService::class.java)
    }

    private lateinit var binding: ActivityMainBinding
    private var currentImageUri: Uri? = null // To store the selected image URI

    // 1. Activity Result Launcher for Gallery
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            currentImageUri = it
            binding.imageViewPhoto.setImageURI(it)
        }
    }

    // 2. Activity Result Launcher for Camera
    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        // The camera result comes back as a Bitmap (if successful)
        bitmap?.let {
            binding.imageViewPhoto.setImageBitmap(it)
            // Note: To send this to an LLM, you'll need to save the Bitmap to a file
            // and get a temporary file URI, which is more complex. For now, we display it.
            // For text/URI use, stick to the gallery for simplicity.
        }
    }

    // 3. Activity Result Launcher for Permission Requests
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // Permission granted, launch the camera/gallery
            Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Permission denied. Cannot access media or camera.", Toast.LENGTH_LONG).show()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the Camera button
        binding.buttonCamera.setOnClickListener {
            // Check for camera permission before launching
            checkPermissionAndLaunch(Manifest.permission.CAMERA, isCamera = true)
        }

        // Set up the Gallery button
        binding.buttonGallery.setOnClickListener {
            galleryLauncher.launch("image/*") // Launch gallery for images
        }
        
        // Set up the Send button
        binding.buttonSend.setOnClickListener {
            val description = binding.inputDescription.text.toString()

            if (description.isBlank()) {
                Toast.makeText(this, "Please describe the issue.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Start the asynchronous LLM call
            callLLM(description, currentImageUri)
        }
    }

    private fun checkPermissionAndLaunch(permission: String, isCamera: Boolean) {
        when {
            // 1. Permission is already granted
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED -> {
                if (isCamera) {
                    cameraLauncher.launch(null) // Launch camera
                } else {
                    // This is the Photo Picker (modern/preferred)
                    galleryLauncher.launch("image/*")
                }
            }
            // 2. Permission is NOT granted, request it
            else -> {
                // This is the line that should trigger the OS permission dialog
                requestPermissionLauncher.launch(permission)
            }
        }
    }
    private fun callLLM(description: String, imageUri: Uri?) {
        binding.textViewResponse.text = "Sending request to Qwen2.5-VL..."

        // Use CoroutineScope to handle the asynchronous network request
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // 1. Prepare image and prompt on a background thread (Dispatchers.IO)
                val promptWithImage = withContext(Dispatchers.IO) {
                    prepareMultiModalPrompt(description, imageUri)
                }

                // 2. Build the request object
                val request = LlmMultiModalRequest(
                    inputs = promptWithImage
                )

                // 3. Make the API call
                val response = apiService.generateContent(
                    token = HF_API_TOKEN,
                    modelName = QWEN_MODEL_NAME,
                    request = request
                )

                // 4. Update the UI with the result
                val llmResponseText = response.firstOrNull()?.generated_text
                    ?: "Error: Could not parse LLM response."

                binding.textViewResponse.text = llmResponseText

            } catch (e: Exception) {
                // Handle network or JSON errors
                binding.textViewResponse.text = "An error occurred: ${e.message}"
                e.printStackTrace()
            }
        }
    }

    private fun prepareMultiModalPrompt(description: String, imageUri: Uri?): String {
        return if (imageUri != null) {
            val base64Image = uriToBase64(imageUri)
            // This is the common format for multimodal models like Qwen: image tag followed by prompt
            "<img src=\"data:image/jpeg;base64,$base64Image\">$description"
        } else {
            description
        }
    }

    /**
     * Utility function to convert a content URI (from gallery/camera) into a Base64 string.
     */
    private fun uriToBase64(uri: Uri): String {
        // Since this runs on Dispatchers.IO, using blocking stream methods is acceptable.
        val inputStream = contentResolver.openInputStream(uri)
        val bitmap = BitmapFactory.decodeStream(inputStream)

        // Reduce image quality/size for faster API upload.
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)

        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}