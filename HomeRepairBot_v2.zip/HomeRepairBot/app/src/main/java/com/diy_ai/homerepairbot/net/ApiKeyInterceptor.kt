package com.diy_ai.homerepairbot.net

import okhttp3.Interceptor
import okhttp3.Response

class ApiKeyInterceptor(private val apiKey: String) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request()
        val builder = req.newBuilder()
            .header("Accept", "application/json")
        if (req.method.uppercase() != "OPTIONS") {
            builder.header("X-API-Key", apiKey)
        }
        return chain.proceed(builder.build())
    }
}
