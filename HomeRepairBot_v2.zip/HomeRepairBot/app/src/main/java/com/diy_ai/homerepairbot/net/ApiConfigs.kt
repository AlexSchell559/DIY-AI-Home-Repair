package com.diy_ai.homerepairbot.net

import com.diy_ai.homerepairbot.BuildConfig
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiConfig {
    // Emulator → host loopback:
    // const val BASE_URL = # deleted for safety reasons
    // If testing on a real device instead, switch to your workstation LAN IP:
     const val BASE_URL = # deleted for safety reasons
    // const val BASE_URL = # deleted for safety reasons

    const val API_KEY  = # deleted for safety reasons

    /** Join BASE_URL with a relative path, handling leading/trailing slashes. */
    fun build(path: String): String {
        val base = BASE_URL.trimEnd('/')
        val rel  = if (path.startsWith("/")) path else "/$path"
        return base + rel
    }

    fun httpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .addInterceptor(ApiKeyInterceptor(API_KEY))   // adds X-API-Key to all non-OPTIONS

        if (BuildConfig.DEBUG) {
            val logger = HttpLoggingInterceptor().apply {
                // BODY lets us see request/response payloads in Logcat (tag: OkHttp)
                level = HttpLoggingInterceptor.Level.BODY
                redactHeader("X-API-Key")
            }
            builder.addNetworkInterceptor(logger)
        }

        return builder.build()
    }



    fun retrofit(): Retrofit =
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
}
