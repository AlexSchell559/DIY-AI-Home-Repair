package com.diy_ai.homerepairbot

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.diy_ai.homerepairbot.net.Repository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ApiSmokeTest {

    @Test
    fun synthesis_text_only_probe() = runBlocking {
        val repo = Repository()
        val resp = repo.synthesisTextOnly(
            text = "drywall inside corner crack repair",
            dialogId = "dlg-as-001",
            intentGate = 0,
            ackStage = 2,
            useLlm = 1
        )

        Log.i("ApiSmokeTest", "ok=${resp.ok} llm_used=${resp.orchestration?.llmUsed}")
        val keys = resp.synthesis?.let { env ->
            listOfNotNull(
                env.causes?.let { "causes" },
                env.scopeOverview?.let { "scope_overview" },
                env.firstStep?.let { "first_step" },
                env.toolsRequired?.let { "tools_required" }
            )
        } ?: emptyList()
        Log.i("ApiSmokeTest", "synthesis keys=$keys images=${resp.synthesis?.imageCitations?.size ?: 0}")

        assertTrue("Backend should return ok=true", resp.ok == true)
    }
}
