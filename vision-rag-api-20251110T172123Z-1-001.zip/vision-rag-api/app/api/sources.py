# app/api/sources.py
from __future__ import annotations
from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
import json

from ..core.settings import settings

router = APIRouter()

# Assumed layout (existing):
# data/
#   page_images/
#     registry.jsonl    <- lines: {"doc_hash": "...", "pdf_path": "..."}
#     <doc_hash>/
#        page_0001.jpg

PAGE_IMAGES_DIR = Path(settings.page_images_dir) if hasattr(settings, "page_images_dir") else Path("./data/page_images")
REGISTRY_PATH   = PAGE_IMAGES_DIR / "registry.jsonl"

# Build an allowlist of roots (absolute, resolved)
_raw_roots = []
if getattr(settings, "allowed_pdf_roots", None):
    _raw_roots.extend(settings.allowed_pdf_roots)
if getattr(settings, "corpus_dir", None):
    _raw_roots.append(settings.corpus_dir)
if getattr(settings, "data_dir", None):
    _raw_roots.append(settings.data_dir)

# Build an allowlist of roots (absolute, resolved) from settings
ALLOWED_ROOTS = []
for p in settings.resolved_allowed_roots():
    try:
        ALLOWED_ROOTS.append(Path(p).resolve())
    except Exception:
        pass

def _safe_under_allowed_roots(p: Path) -> bool:
    try:
        rp = p.resolve()
    except Exception:
        return False
    for root in ALLOWED_ROOTS:
        if rp == root or root in rp.parents:
            return True
    return False

def _load_registry() -> dict[str, str]:
    """
    Returns mapping pdf_path -> doc_hash.
    """
    mapping: dict[str, str] = {}
    if not REGISTRY_PATH.exists():
        return mapping
    with REGISTRY_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                pdf_path = str(obj.get("pdf_path", "")).strip()
                doc_hash = str(obj.get("doc_hash", "")).strip()
                if pdf_path and doc_hash:
                    # Normalize to absolute real path for robust matching
                    mapping[str(Path(pdf_path).resolve())] = doc_hash
            except Exception:
                continue
    return mapping

@router.get("/registry/lookup")
def lookup_doc_hash(pdf_path: str = Query(..., description="Absolute path to the source PDF")):
    try:
        pdf_abs = Path(pdf_path).resolve()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid pdf_path")
    reg = _load_registry()
    doc_hash = reg.get(str(pdf_abs))
    if not doc_hash:
        raise HTTPException(status_code=404, detail="Document not found in registry")
    return {"pdf_path": str(pdf_abs), "doc_hash": doc_hash}
    
@router.get("/get-image")
def get_page_image(
    pdf_path: str = Query("", description="Absolute path to the source PDF"),
    page: int = Query(1, ge=1, description="1-based page index"),
    doc_hash: str = Query("", description="Optional: provide doc_hash to bypass registry"),
):
    # If doc_hash provided, use it directly
    if doc_hash:
        img_name = f"page_{page:04d}.jpg"
        img_path = PAGE_IMAGES_DIR / doc_hash / img_name
        if not img_path.exists():
            raise HTTPException(status_code=404, detail="Page image not found for doc_hash")
        return FileResponse(str(img_path), media_type="image/jpeg", filename=img_name)

    # Fallback path: require pdf_path and look up in registry
    if not pdf_path:
        raise HTTPException(status_code=400, detail="Either doc_hash or pdf_path is required")

    try:
        pdf_abs = Path(pdf_path).resolve()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid pdf_path")

    if not _safe_under_allowed_roots(pdf_abs):
        raise HTTPException(status_code=403, detail="pdf_path is not under the allowed roots")

    reg = _load_registry()
    doc_hash = reg.get(str(pdf_abs))
    if not doc_hash:
        raise HTTPException(status_code=404, detail="Document not found in registry")

    img_name = f"page_{page:04d}.jpg"
    img_path = PAGE_IMAGES_DIR / doc_hash / img_name
    if not img_path.exists():
        raise HTTPException(status_code=404, detail="Page image not found")

    return FileResponse(str(img_path), media_type="image/jpeg", filename=img_name)

@router.get("/get-pdf")
def get_pdf(
    pdf_path: str = Query(..., description="Absolute path to the source PDF"),
):
    """
    (Optional) Return the original PDF bytes, guarded by corpus root.
    """
    if not pdf_path:
        raise HTTPException(status_code=400, detail="pdf_path is required")
    try:
        pdf_abs = Path(pdf_path).resolve()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid pdf_path")

    if not _safe_under_allowed_roots(pdf_abs):
        raise HTTPException(status_code=403, detail="pdf_path is not under the allowed roots")

    if not pdf_abs.exists() or pdf_abs.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found")

    return FileResponse(
        path=str(pdf_abs),
        media_type="application/pdf",
        filename=pdf_abs.name
    )

