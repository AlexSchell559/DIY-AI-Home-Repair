# app/api/dialog.py
from __future__ import annotations
from fastapi import APIRouter, Query, HTTPException
from typing import Any, Dict
from app.services.session import load_session, session_path

router = APIRouter()

@router.get("/state")
def read_dialog_state(dialog_id: str = Query(..., description="Session/dialog identifier")) -> Dict[str, Any]:
    """
    Returns the current chat_info.json for dialog_id (creating an in-memory default if missing).
    """
    if not dialog_id:
        raise HTTPException(status_code=400, detail="dialog_id is required")

    data = load_session(dialog_id)
    # Optional: include a hint whether a file exists on disk
    data["_exists_on_disk"] = session_path(dialog_id).exists()
    return data

