"""
Adds:
- prompt->query generation
- text RAG + whitelist Google CSE
- simple rank fusion + safety tagging is already handled in RAG + fusion; we combine lists here.
"""

from pathlib import Path
from io import BytesIO
from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, Form, Depends
from PIL import Image
from pydantic import BaseModel

from app.services.safety import safety_payload, analyze_text_blocks, SafetyReport
from app.services.intent import decide_intent
from ..core.settings import settings
from ..vlm.qwen_captioner import get_captioner
from ..rag.image_indexer import search_by_image
from ..rag.fusion import fuse_image_hits_with_text
from ..rag.indexer import search as rag_search
from ..search.schema import SearchQuery
from ..search.service import search_service
from ..services.query_gen import synthesize_query, QueryInputs
from ..services.filters import apply_filters
from app.services.session import (
    load_session, save_session, add_citations, add_context_snippets,
    maybe_skip_heavy_work, record_query
)

router = APIRouter(prefix="/api/v1/rag/fusion", tags=["fusion"])

class FusionResponse(BaseModel):
    # Required
    schema_version: str
    ok: bool

    # Query echo
    query_caption: str | None = None
    query_text: str | None = None

    # Results payload (your handler returns 'results', not 'items')
    results: list[dict] = []

    # Safety + warnings
    warnings: SafetyReport
    safety: dict | None = None

    # Intent gate
    intent_decision: dict | None = None

    # Misc
    notes: dict | None = None
    _debug: dict | None = None

    # Allow extra keys if we add fields later without breaking clients
    model_config = {"extra": "allow"}

@router.post("/search", response_model=FusionResponse)
async def fusion_search(
    image: UploadFile | None = File(default=None),
    text: str | None = Form(default=None),
    k: int = Form(default=5),
    # --- SearchLVLM-style filters (optional; AND semantics) ---
    room: str | None = Form(default=None),
    material: str | None = Form(default=None),
    component: str | None = Form(default=None),
    tool: str | None = Form(default=None),
    # --- Intent gate controls ---
    intent_gate: int = Form(default=1),   # 1=enabled, 0=disabled
    ack_stage: int   = Form(default=0),   # 0,1,2 (user acknowledgments)
    debug: int       = Form(default=0),   # 1 to include _debug branch info
    # --- Session logs and references ---
    dialog_id: str | None = Form(default=None)

):
    """
    Fusion flow (image+text+web), with:
      - Optional image (caption + CLIP neighbors)
      - Text RAG over local PDFs
      - Whitelist web search (Google CSE)
      - Merge + filter + truncate
      - Safety analysis (warnings + staged + emergency)
      - Intent gate (emergency/stage gating) BEFORE returning results
      - Always finalize response via _finalize_response (schema_version + safety)
    """
    # Session bootstrap (optional per-dialogue state)
    sess = None
    if dialog_id:
        sess = load_session(dialog_id)

    # --- Helper: always enrich the payload with schema_version and safety
    def _finalize_response(payload: dict, *, text_blocks: list[str], branch: str = "") -> dict:
        safety = safety_payload(text_blocks)
        out = dict(payload)
        out["schema_version"] = settings.schema_version
        out["safety"] = safety
        if debug:
            out["_debug"] = {"branch": branch}
        return out

    try:
        # 1) Decode image (optional) + caption
        caption = ""
        img = None
        if image is not None:
            raw = await image.read()
            img = Image.open(BytesIO(raw)).convert("RGB")
            caption = get_captioner().caption(img)

        # 2) Build succinct search query from caption + user text
        query = synthesize_query(QueryInputs(caption=caption, user_text=text))
        if sess and maybe_skip_heavy_work(sess, query):
            # Use prior context; do not run RAG/Web. Keep image fuse if present.
            skip_rag = True
            skip_web = True
        else:
            skip_rag = False
            skip_web = False
        if sess:
            record_query(sess, query, ack_stage=ack_stage)
            
        # 3) Visual neighbors (only if we have an image) + fuse with local snippets
        if img is not None:
            vis = search_by_image(
                img=img,
                index_dir=Path(settings.image_index_dir),
                model_name=settings.image_embed_model_name,
                k=k,
            )
            if not vis.get("ok"):
                # keep moving with empty image results
                fused_local = {"ok": True, "results": [], "warnings": []}
                branch_vis = "image_vis_not_ok"
            else:
                fused_local = fuse_image_hits_with_text(vis["results"], data_dir=Path(settings.data_dir))
                if not fused_local.get("ok"):
                    fused_local = {"ok": True, "results": [], "warnings": []}
                    branch_vis = "image_fuse_empty"
                else:
                    branch_vis = "image_fuse_ok"
        else:
            fused_local = {"ok": True, "results": [], "warnings": []}
            branch_vis = "no_image"

        # 4) Text RAG over local PDFs
        rag = {"ok": False, "results": []}
        if not skip_rag:
            rag = rag_search(query=query, data_dir=Path(settings.data_dir), top_k=k)
        # 5) Whitelist web search
        web = {"ok": False, "results": []}
        if not skip_web:
            web_resp = search_service(SearchQuery(query=query, max_results=k))
            if hasattr(web_resp, "model_dump"):
                web = web_resp.model_dump()
            elif isinstance(web_resp, dict):
                web = web_resp
            else:
                web = {"ok": False, "results": [], "notes": "unexpected web response type"}

        # 6) Merge for ranking + dedupe + truncate snippets
        def _rank_key(r: dict) -> float:
            return float(r.get("score", 0.7))

        def _truncate(s: str, n: int) -> str:
            s = (s or "").strip()
            return (s[: n - 1] + "…") if len(s) > n else s

        def _coerce_results_for_merge(image_res: dict, rag_res: dict, web_res: dict) -> list[dict]:
            out: list[dict] = []
            # image
            img_cap = settings.fusion_per_source_cap
            for it in (image_res.get("results", [])[:img_cap]):
                out.append({
                    "type": "image",
                    "score": float(it.get("score", 0.0)),
                    "image_path": it.get("image_path"),
                    "pdf_path": it.get("pdf_path"),
                    "page_index": it.get("page_index"),
                    "snippets": [
                        _truncate(sn, settings.snippet_char_limit)
                        for sn in it.get("snippets", [])
                    ],
                })
            # web
            if web_res.get("ok"):
                for hit in web_res.get("results", []):
                    out.append({
                        "type": "web",
                        "score": float(hit.get("score", 0.5)),
                        "title": hit.get("title",""),
                        "url": str(hit.get("url","")),
                        "snippet": hit.get("snippet",""),
                    })
            # text RAG (optional; add if you want visible)
            if rag_res.get("ok"):
                for hit in rag_res.get("results", []):
                    out.append({
                        "type": "text",
                        "score": float(hit.get("score", 0.6)),
                        "pdf_path": hit.get("pdf_path"),
                        "page_index": hit.get("page"),
                        "snippet": _truncate(hit.get("snippet",""), settings.snippet_char_limit),
                    })
            return out

        def _dedup_keep_best(items: list[dict]) -> list[dict]:
            seen = {}
            for x in items:
                if x["type"] == "web":
                    key = ("web", x.get("url",""))
                elif x["type"] in ("image","text"):
                    key = ("pdf", x.get("pdf_path",""), x.get("page_index"))
                else:
                    key = ("other", repr(x))
                if key not in seen or _rank_key(x) > _rank_key(seen[key]):
                    seen[key] = x
            return sorted(seen.values(), key=_rank_key, reverse=True)

        merged = _coerce_results_for_merge(fused_local, rag, web)
        merged = _dedup_keep_best(merged)

        # 7) Apply SearchLVLM-style filters (AND semantics)
        cfg = {
            "room": settings.filter_synonyms_room,
            "material": settings.filter_synonyms_material,
            "component": settings.filter_synonyms_component,
            "tool": settings.filter_synonyms_tool,
        }
        filtered = apply_filters(
            merged,
            room=room, material=material, component=component, tool=tool,
            cfg=cfg
        )
        final_items = filtered["items"][: settings.fusion_max_total]
        filter_notes = filtered["notes"]

        # 8) Build text blocks (caption, user text, snippets/titles) for safety/intents
        text_blocks: list[str] = []
        if text:
            text_blocks.append(text)
        if isinstance(caption, str) and caption:
            text_blocks.append(caption)
        for it in final_items:
            t = it.get("type")
            if t == "image":
                for sn in (it.get("snippets") or []):
                    if sn: text_blocks.append(sn)
            elif t == "web":
                if it.get("title"):   text_blocks.append(it["title"])
                if it.get("snippet"): text_blocks.append(it["snippet"])
            elif t == "text":
                if it.get("snippet"): text_blocks.append(it["snippet"])
        # --- Session update ---
        if sess:
            # 1) Add citations from results (web/text/image)
            add_citations(sess, final_items)

            # 2) Add supporting snippets into the rolling context (budget ~50% of 32k)
            #    pull from the items we actually returned to the client
            carry_snips = []
            for it in final_items:
                t = it.get("type")
                if t == "web":
                    if it.get("title"):   carry_snips.append(it["title"])
                    if it.get("snippet"): carry_snips.append(it["snippet"])
                elif t == "text":
                    if it.get("snippet"): carry_snips.append(it["snippet"])
                elif t == "image":
                    # optional: image snippets if present
                    for sn in (it.get("snippets") or []):
                        if sn: carry_snips.append(sn)

            add_context_snippets(sess, carry_snips)

            # 3) Persist the session
            save_session(sess["dialog_id"], sess)
            
        # 9) Intent Gate (after safety computed, before returning results)
        safety = safety_payload(text_blocks)
        intent = decide_intent(safety, ack_stage=ack_stage)
        
        # Enrich intent_decision with ack stage and staged messages for the client UI
        intent["ack_stage"] = ack_stage
        intent["staged_messages"] = safety.get("staged", [])

        if intent_gate and intent["decision"] in ("emergency_override", "stage_1_required", "stage_2_required"):
            # short-circuit: return gating info only (no how-to/results)
            payload = {
                "ok": True,
                "dialog_id": dialog_id,
                "intent_decision": intent,
                "query_caption": caption,
                "query_text": text or "",
                "results": [],
                "warnings": analyze_text_blocks(text_blocks),  # compact summary model
                "notes": {"filters": filter_notes, "vis_branch": branch_vis},
            }
            return _finalize_response(payload, text_blocks=text_blocks, branch="intent_gate_block")

        # 10) Proceed path: attach results + warnings + intent visibility
        payload = {
            "ok": True,
            "dialog_id": dialog_id,
            "intent_decision": intent,
            "query_caption": caption,
            "query_text": text or "",
            "results": final_items,
            "warnings": analyze_text_blocks(text_blocks),
            "notes": {
                "image_hits": len(fused_local.get("results", [])),
                "rag_hits": len(rag.get("results", [])) if rag.get("ok") else 0,
                "web_hits": len(web.get("results", [])) if web.get("ok") else 0,
                "filters": filter_notes,
                "vis_branch": branch_vis,
            },
        }
        return _finalize_response(payload, text_blocks=text_blocks, branch="final")

    except Exception as e:
        # Ensure errors still return schema_version+safety for easier debugging
        tb_payload = {
            "ok": False,
            "error": f"fusion-search-failed: {e!r}",
            "results": [],
            "warnings": {"warnings": []},  # shape-compatible stub
            "notes": {},
        }
        # On exception we likely don't have meaningful text_blocks; use caption/text if present
        text_blocks = [x for x in [text, caption] if x]
        return _finalize_response(tb_payload, text_blocks=text_blocks, branch="exception")
