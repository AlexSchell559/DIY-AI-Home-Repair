# app/services/session.py
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List
from datetime import datetime

# Root folder for per-dialogue state:
# Each dialog gets: ./data/sessions/<dialog_id>/chat_info.json
SESS_ROOT = Path("./data/sessions")

def _now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def session_path(dialog_id: str) -> Path:
    return SESS_ROOT / dialog_id / "chat_info.json"

def load_session(dialog_id: str) -> Dict[str, Any]:
    """
    Load or initialize a session dict.
    """
    sp = session_path(dialog_id)
    if sp.exists():
        try:
            return json.loads(sp.read_text(encoding="utf-8"))
        except Exception:
            # Corrupt file: fall back to fresh
            pass
    # Fresh seed
    return {
        "dialog_id": dialog_id,
        "created_at": _now_iso(),
        "ack_stage": 0,
        "last_query": "",
        "context_budget_chars": 16000 * 4,  # ~16k tokens ~ 4 chars/token ~= 64k chars
        "context_used_chars": 0,
        "selected_results": [],     # chosen items user wants to keep
        "last_snippets": [],        # recent supporting text
        "progress": [],             # [{step,confirmed,timestamp}]
        "citations": [],            # normalized list across web/text/image
    }

def save_session(dialog_id: str, data: Dict[str, Any]) -> None:
    """
    Persist the session JSON (atomic enough for our single-process flow).
    """
    sp = session_path(dialog_id)
    _ensure_dir(sp.parent)
    sp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def estimate_chars(s: str | None) -> int:
    """
    Cheap budget guard: approximate tokens via chars; good enough for gating.
    """
    if not s: return 0
    return len(s)

def add_citations(sess: Dict[str, Any], items: List[Dict[str, Any]]) -> None:
    """
    Extract normalized citations from fusion results and append,
    avoiding obvious duplicates.
    Schema:
      - web:   {"type":"web","url":..., "title":..., "snippet":...}
      - text:  {"type":"text","pdf_path":..., "page_index":..., "snippet":...}
      - image: {"type":"image","pdf_path":..., "page_index":..., "image_path":...}
    """
    seen = {json.dumps(c, sort_keys=True) for c in sess.get("citations", [])}
    new = []
    for it in items:
        t = it.get("type")
        if t == "web":
            c = {
                "type": "web",
                "url": it.get("url", ""),
                "title": it.get("title", ""),
                "snippet": it.get("snippet", ""),
            }
        elif t == "text":
            c = {
                "type": "text",
                "pdf_path": it.get("pdf_path", ""),
                "page_index": it.get("page_index") or it.get("page"),
                "snippet": it.get("snippet", ""),
            }
        elif t == "image":
            c = {
                "type": "image",
                "pdf_path": it.get("pdf_path", ""),
                "page_index": it.get("page_index"),
                "image_path": it.get("image_path", ""),
            }
        else:
            continue
        key = json.dumps(c, sort_keys=True)
        if key not in seen:
            seen.add(key)
            new.append(c)
    if new:
        sess.setdefault("citations", []).extend(new)

def add_context_snippets(sess: Dict[str, Any], snippets: List[str], max_chars: int | None = None) -> None:
    """
    Append snippets into rolling context until budget (~50% of 32k tokens) is hit.
    """
    if max_chars is None:
        max_chars = sess.get("context_budget_chars", 64000)
    used = sess.get("context_used_chars", 0)
    keep = []
    for s in snippets:
        c = estimate_chars(s)
        if used + c > max_chars:
            break
        keep.append(s)
        used += c
    if keep:
        sess.setdefault("last_snippets", []).extend(keep)
        sess["context_used_chars"] = used

def maybe_skip_heavy_work(sess: Dict[str, Any], query: str) -> bool:
    """
    Policy: if the query hasn't changed and we already have citations/snippets,
    skip RAG/Web this turn and rely on cached session context.
    """
    if not query:
        return False
    if sess.get("last_query") == query and (sess.get("citations") or sess.get("last_snippets")):
        return True
    return False

def record_query(sess: Dict[str, Any], query: str, ack_stage: int) -> None:
    sess["last_query"] = query
    sess["ack_stage"] = ack_stage

def record_progress(sess: Dict[str, Any], step: str, confirmed: bool) -> None:
    sess.setdefault("progress", []).append({
        "step": step,
        "confirmed": bool(confirmed),
        "timestamp": _now_iso()
    })

