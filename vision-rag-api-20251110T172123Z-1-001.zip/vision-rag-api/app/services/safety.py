"""
Purpose:
- Post-process RAG/Search results for safety-sensitive topics and attach warnings.
- Minimal keyword/regex rules for: GAS, APPLIANCE, ELECTRICAL (risky).
- Non-blocking: we never hide results; we only annotate with flags + advisories.

How it's used:
- For each result, we scan the snippet (and optionally a title/path) for matches.
- We aggregate a global warnings list (unique advisories) for the whole response.

Extensibility:
- Add/adapt rules in HAZARD_RULES.
- Tweak advisory text in ADVISORIES.
"""

from __future__ import annotations
from dataclasses import dataclass
from pydantic import BaseModel, Field
from typing import List, Dict, Tuple, Any
import re

# ---------- Data Models ----------

class SafetyWarning(BaseModel):
    category: str            # e.g., "electrical", "gas", "hazmat", "appliance"
    level: str               # "info" | "caution" | "stop"
    reason: str              # brief human-readable why
    signals: List[str] = Field(default_factory=list)  # matched keywords/phrases

class SafetyReport(BaseModel):
    warnings: List[SafetyWarning] = Field(default_factory=list)

# ---------- Category Rules (for compact report.warnings) ----------

CATEGORY_RULES: Dict[str, Dict[str, List[str]]] = {
    "electrical": {
        "stop": [
            r"\bexposed (lugs|bus|conductors?)\b",
            r"\b(main )?service panel\b.*\bopen\b",
            r"\b(live|energized)\s+(wire|conductor)\b",
            r"\bsparking\b", r"\barc(ing)?\b",
            r"\b240\s*v\b", r"\b(aluminum branch|double[- ]tap)\b",
        ],
        "caution": [
            r"\btripped (breaker|gfci)\b", r"\bgfci\b", r"\bopen (junction|j[- ]?box)\b",
            r"\bneutral\b.*\bground(ed)?\b", r"\bloose outlet\b",
        ],
        "info": [r"\bbreaker\b", r"\boutlet\b", r"\bextension cord\b"],
    },
    "gas": {
        "stop": [
            r"\bgas (leak|odor|smell)\b", r"\bsmell(s|ed)? gas\b",
            r"\bco\b|\bcarbon monoxide\b", r"\bpilot\b.*\bleak\b",
        ],
        "caution": [r"\bpilot (light|relight)\b", r"\bthermocouple\b", r"\bcombustion air\b"],
        "info": [r"\bnatural gas\b", r"\bpropane\b"],
    },
    "hazmat": {
        "stop": [r"\bchemical spill\b", r"\basbestos\b", r"\blead paint\b", r"\bpcbs?\b"],
        "caution": [r"\bmold\b", r"\bblack mold\b"],
        "info": [r"\btest kit\b", r"\babatement\b"],
    },
    "appliance": {
        "stop": [
            r"\bgas\s+(dryer|oven|range|furnace|boiler|water heater)\b",
            r"\b(flue|vent)\s+(blocked|cracked)\b",
        ],
        "caution": [
            r"\b(water heater|furnace|boiler|dryer|oven|range|dishwasher|refrigerator)\b",
            r"\b(igniter|thermocouple|pilot|combustion)\b",
        ],
        "info": [r"\bmanufacturer (manual|guide)\b"],
    },
    "fire_smoke": {
        "stop": [r"\b(active )?fire\b", r"\bvisible smoke\b", r"\bsmoke\b.*\bin (house|home|room)\b"],
        "caution": [r"\bscorch(ed)?\b", r"\bsoot\b"],
        "info": [r"\bsmoke (alarm|detector)\b"],
    },
    "water_structural": {
        "stop": [r"\b(load[- ]bearing|structural)\b.*\b(remove|cut)\b", r"\broof\b.*\b(sag|collapse)\b"],
        "caution": [r"\bleak(ing)?\b", r"\bactive leak\b", r"\bdrywall\b.*\bsoft\b", r"\bsubfloor\b.*\brot\b"],
        "info": [r"\bmoisture\b", r"\bdrip\b"],
    },
}

LEVEL_ORDER = ["info", "caution", "stop"]
LEVEL_SCORE = {"info": 1, "caution": 2, "stop": 3}

def _scan_text_for_category(text: str, patterns: Dict[str, List[str]]) -> Tuple[str, List[str]]:
    best_level, hits = "", []
    for level in LEVEL_ORDER:
        for pat in patterns.get(level, []):
            if re.search(pat, text, flags=re.IGNORECASE):
                hits.append(pat)
                if LEVEL_SCORE[level] > LEVEL_SCORE.get(best_level, 0):
                    best_level = level
    return best_level, hits

def analyze_text_blocks(blocks: List[str]) -> SafetyReport:
    """
    Build a compact report across categories for UI/logs.
    """
    joined = "\n".join([b for b in blocks if b])[:200_000]
    warnings: List[SafetyWarning] = []
    for category, patterns in CATEGORY_RULES.items():
        level, hits = _scan_text_for_category(joined, patterns)
        if level:
            reason = {
                "stop": "Multiple high-risk indicators detected.",
                "caution": "Potentially hazardous condition detected.",
                "info": "General safety consideration applicable.",
            }[level]
            warnings.append(SafetyWarning(
                category=category.replace("_", "/"),
                level=level,
                reason=reason,
                signals=hits[:5],
            ))
    # simple compounding: gas + fire → stop for both
    cats = {w.category for w in warnings}
    if "gas" in cats and "fire/smoke" in cats:
        for w in warnings:
            if w.category in ("gas", "fire/smoke"):
                w.level, w.reason = "stop", "Compound risk: gas + fire/smoke indicators."
    return SafetyReport(warnings=warnings)

# ---------- Staged Warnings + Emergency Stub (for gate/UX) ----------

# “Work type” detection for staged messages
STAGE_TYPES: Dict[str, List[str]] = {
    "Gas line work": [
        r"\bgas\s+(line|pipe|valve|fitting|meter)\b", r"\bgas\s+leak\b", r"\bshut\s*off\s+gas\b",
    ],
    "Electrical (beyond low-risk)": [
        r"\b(service|breaker)\s+panel\b", r"\blive\s+wire\b", r"\bwiring\b", r"\bjunction\s+box\b",
        r"\b240\s*v\b", r"\bline\s+voltage\b",
    ],
    "Hazardous materials": [
        r"\bchemical spill\b", r"\basbestos\b", r"\blead paint\b", r"\bpcbs?\b",
    ],
    "Appliance service": [
        r"\b(water heater|furnace|boiler|dryer|oven|range|dishwasher|refrigerator)\b",
        r"\b(igniter|thermocouple|pilot|flue|vent|combustion)\b",
    ],
}

EMERGENCY_PATTERNS = [
    (r"\bchemical spill\b", "Chemical spill"),
    (r"\b(active )?fire\b", "Active fire"),
    (r"\b(live|energized)\s+(wire|conductor)\b", "Live electrical discharge"),
    (r"\barc(ing)?\b|\bsparking\b", "Electrical arcing/sparking"),
    (r"\bstrong\s+gas\s+odor\b|\bsmell(s|ed)?\s+gas\b", "Strong gas odor"),
]

def _find_types(joined: str) -> List[str]:
    types = []
    for t, pats in STAGE_TYPES.items():
        if any(re.search(p, joined, flags=re.IGNORECASE) for p in pats):
            types.append(t)
    return types

def _detect_emergency(joined: str) -> Dict[str, Any]:
    hits = []
    for pat, label in EMERGENCY_PATTERNS:
        if re.search(pat, joined, flags=re.IGNORECASE):
            hits.append(label)
    return {
        "detected": bool(hits),
        "message": "Emergency detected! Please dial 911 or contact local/regional emergency services immediately!"
                   if hits else "",
        "signals": hits[:5],
    }

def build_staged_messages(types: List[str]) -> List[Dict[str, str]]:
    """
    Stage 1 then Stage 2 messages. You can display them sequentially if the user
    chooses to continue after seeing Stage 1.
    """
    if not types:
        return []
    kind = ", ".join(types)
    return [
        {
            "stage": "1",
            "text": f"Warning: This repair involves {kind}. An AI Assistant is not qualified to help this type of repair. Please contact a professional in your area."
        },
        {
            "stage": "2",
            "text": "As an AI repair assistant, I am not qualified to help you with this repair. Please contact a professional. If you continue to seek my help to work on this repair, you are agreeing not to hold Rep.AI.r, or its creators, responsible for any additional issues that may arise."
        },
    ]

def safety_payload(blocks: List[str]) -> Dict[str, Any]:
    """
    Unified payload for API responses:
      - report: compact category/level summary (SafetyReport)
      - staged: list of staged advisory messages (Stage 1, Stage 2)
      - emergency: emergency stub (detected/message/signals)
    """
    joined = "\n".join([b for b in blocks if b])[:200_000]
    report = analyze_text_blocks(blocks)
    types = _find_types(joined)
    staged = build_staged_messages(types)
    emergency = _detect_emergency(joined)
    return {
        "report": report.model_dump(),
        "staged": staged,
        "emergency": emergency,
        "work_types": types,
    }

# --- Back-compat shims for existing imports (e.g., health.py) ---

def analyze_snippets(snippets: List[str]) -> SafetyReport:
    """
    Backward-compatible alias used by legacy modules.
    Mirrors old behavior by delegating to analyze_text_blocks.
    """
    return analyze_text_blocks(snippets)

def analyze_snippets_json(snippets: List[str]) -> Dict[str, Any]:
    """
    Optional: JSON-friendly variant if any caller expects a plain dict.
    """
    return analyze_text_blocks(snippets).model_dump()

