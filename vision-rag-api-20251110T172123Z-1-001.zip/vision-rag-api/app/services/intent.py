# app/services/intent.py
from __future__ import annotations
from typing import List, Dict, Any

# Decision values:
#   emergency_override  -> hard stop, show emergency message only
#   stage_1_required    -> show staged[0] and stop (until ack)
#   stage_2_required    -> show staged[1] and stop (until ack)
#   proceed             -> okay to show fus’d guidance/results

def decide_intent(safety: Dict[str, Any], ack_stage: int) -> Dict[str, Any]:
    """
    safety: output of safety_payload(...)
    ack_stage: 0 (no ack), 1 (stage 1 acknowledged), 2+ (stage 2 acknowledged)
    """
    emergency = safety.get("emergency") or {}
    staged = safety.get("staged") or []
    work_types = safety.get("work_types") or []

    # 1) Emergency stub → immediate override
    if emergency.get("detected"):
        return {
            "decision": "emergency_override",
            "message": emergency.get("message", "Emergency detected!"),
            "signals": emergency.get("signals", []),
            "require_ack_stage": None,
            "work_types": work_types,
        }

    # 2) Stage-gated warnings for pro-level categories
    if work_types:  # we found Gas line work / Electrical / Hazmat / Appliance service
        if ack_stage < 1:
            return {
                "decision": "stage_1_required",
                "message": staged[0]["text"] if staged else "",
                "require_ack_stage": 1,
                "work_types": work_types,
            }
        if ack_stage < 2:
            return {
                "decision": "stage_2_required",
                "message": staged[1]["text"] if len(staged) > 1 else "",
                "require_ack_stage": 2,
                "work_types": work_types,
            }

    # 3) Otherwise proceed
    return {
        "decision": "proceed",
        "message": "",
        "signals": [],
        "require_ack_stage": None,
        "work_types": work_types,
    }

