"""
Purpose:
- Centralized configuration using pydantic-settings.
- Reads from environment variables and optional .env file.
- Keeps paths and host/port tunable without code changes.
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Optional, Dict, Any
import os, json
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Central configuration (Pydantic v2).
    - Accepts JSON arrays OR CSV strings for list fields.
    - Provides back-compat aliases (e.g., embed_model_name -> text_embed_model_name).
    """

    # Base
    # pydantic v2-style config
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="allow",             # <- allow other env keys without failing
    )

    # --- Server basics (from .env) ---
    host: Optional[str] = Field(default=None, alias="HOST")
    port: Optional[int] = Field(default=None, alias="PORT")
    
    # -------- Server / App --------
    api_bind_host: str = Field(default="0.0.0.0", alias="API_BIND_HOST")
    api_bind_port: int = Field(default=8000, alias="API_BIND_PORT")
    public_base_url: Optional[str] = Field(default=None, alias="PUBLIC_BASE_URL")

    # -------- Paths / Data roots --------
    data_dir: str = Field(default="./data", alias="DATA_DIR")
    page_images_dir: str = Field(default="./data/page_images", alias="PAGE_IMAGES_DIR")
    image_index_dir: str = Field(default="./data/image_index", alias="IMAGE_INDEX_DIR")

    # Single-root options (optional)
    corpus_dir: Optional[str] = Field(default=None, alias="CORPUS_DIR")
    pdf_dir: Optional[str]    = Field(default=None, alias="PDF_DIR")

    # Allowlist roots (optional)
    allowed_pdf_roots: List[str] = Field(default_factory=list, alias="ALLOWED_PDF_ROOTS")

    # -------- Models / Embeddings / VLM --------
    # Text/image embedding models
    text_embed_model_name: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2",
        alias="TEXT_EMBED_MODEL_NAME"
    )
    image_embed_model_name: str = Field(
        default="sentence-transformers/clip-ViT-B-32",
        alias="IMAGE_EMBED_MODEL_NAME"
    )

    # VLM / Qwen
    qwen_model_name: str = Field(default="Qwen/Qwen2.5-VL-3B-Instruct", alias="QWEN_MODEL_NAME")
    
    # --- Whitelist paths & domains ---
    # IMPORTANT: must be a typed field, not a @property
    search_whitelist_file: str = Field(default="", alias="WHITELIST_URLS_PATH")

    # domains can come from JSON list or CSV in .env
    whitelist_domains: List[str] = Field(default_factory=list, alias="WHITELIST_DOMAINS")
    allowed_domains: List[str]  = Field(default_factory=list)   # derived (fallback below)
    allowed_repos:  List[str]   = Field(default_factory=list)   # optional, stays empty unless used

    # --- Qwen (match your .env) ---
    qwen_model_id: Optional[str] = Field(default=None, alias="QWEN_MODEL_ID")
    qwen_device:   Optional[str] = Field(default=None, alias="QWEN_DEVICE")
    qwen_dtype:    Optional[str] = Field(default=None, alias="QWEN_DTYPE")
    # --- Qwen memory / offload knobs (back-compat with qwen_captioner.py) ---
    # Max GPU VRAM (GiB) you want to allocate; None = let HF/accelerate decide
    qwen_gpu_max_gb: Optional[float] = Field(default=None, alias="QWEN_GPU_MAX_GB")
    # Max CPU RAM (GiB) for offload; None = default
    qwen_cpu_max_gb: Optional[float] = Field(default=None, alias="QWEN_CPU_MAX_GB")
    # Optional explicit accelerate-style max_memory mapping as JSON, e.g.
    # {"0": "14GiB", "cpu": "24GiB"}
    qwen_max_memory: Optional[Dict[str, str]] = Field(default=None, alias="QWEN_MAX_MEMORY")
    qwen_context_tokens: int = Field(default=32768, alias="QWEN_CONTEXT_TOKENS")
    qwen_device_map: str = Field(default="auto", alias="QWEN_DEVICE_MAP")  # auto|cpu|cuda
    qwen_torch_dtype: Optional[str] = Field(default=None, alias="QWEN_TORCH_DTYPE")  # bf16|fp16|fp32|auto/None
    qwen_offload_folder: str = Field(default="./data/qwen_offload", alias="QWEN_OFFLOAD_FOLDER")
    use_qwen_captioner: bool = Field(default=True, alias="USE_QWEN_CAPTIONER")
    qwen_max_new_tokens: int = Field(default=48, alias="QWEN_MAX_NEW_TOKENS")
    qwen_temperature: float = Field(default=0.2, alias="QWEN_TEMPERATURE")
    qwen_top_p: float = Field(default=0.9, alias="QWEN_TOP_P")
    qwen_attn_impl: Optional[str] = Field(default=None, alias="QWEN_ATTN_IMPL")

    # -------- Search / CSE / Whitelist --------
    google_api_key: Optional[str] = Field(default=None, alias="GOOGLE_API_KEY")
    google_text_cse_id: Optional[str] = Field(default=None, alias="GOOGLE_TEXT_CSE_ID")
    google_image_cse_id: Optional[str] = Field(default=None, alias="GOOGLE_IMAGE_CSE_ID")
    whitelist_urls_path: str = Field(default="./whitelist_urls.txt", alias="WHITELIST_URLS_PATH")

    # -------- Fusion / IO controls --------
    fusion_per_source_cap: int = 5
    fusion_max_total: int = 10
    snippet_char_limit: int = 280
    k_max: int = Field(default=10, alias="K_MAX")
    verbosity: str = Field(default="normal", alias="VERBOSITY")  # brief|normal|detailed
    schema_version: str = Field(default="v1.1", alias="SCHEMA_VERSION")

    # -------- Filters (SearchLVLM-style) --------
    filter_synonyms_room: Dict[str, Any] = Field(default_factory=dict)
    filter_synonyms_material: Dict[str, Any] = Field(default_factory=dict)
    filter_synonyms_component: Dict[str, Any] = Field(default_factory=dict)
    filter_synonyms_tool: Dict[str, Any] = Field(default_factory=dict)

    # -------- Auth / CORS / Rate limiting --------
    # --- API keys (list from .env: JSON or CSV) ---
    api_keys: List[str] = Field(default_factory=list, alias="API_KEYS")
    search_whitelist_file: str = os.getenv("WHITELIST_URLS_PATH", "")
    whitelist_domains: List[str] = []
    allowed_domains: List[str] = []
    allowed_repos: List[str] = []
    cors_allow_origins: List[str] = Field(default_factory=list, alias="CORS_ALLOW_ORIGINS")
    rate_limit_rps: float = Field(default=2.0, alias="RATE_LIMIT_RPS")
    rate_limit_burst: int = Field(default=6, alias="RATE_LIMIT_BURST")

    # Accept older/alternate envs if present
    # (env fallback for model/device/dtype)
    @field_validator("whitelist_urls_path", mode="after")
    @classmethod
    def _norm_whitelist_path(cls, v: str) -> str:
        # expand ~ and make absolute; keep as string (Settings fields are strings)
        try:
            return str(Path(v).expanduser().resolve())
        except Exception:
            return v
            
    # helper function to ensure bool compatibility
    @field_validator("use_qwen_captioner", mode="before")
    @classmethod
    def _boolish(cls, v):
        # Accept True/False, 1/0, yes/no (case-insensitive), or already-boolean
        if isinstance(v, bool):
            return v
        if v is None:
            return True
        s = str(v).strip().lower()
        if s in {"1", "true", "t", "yes", "y"}:
            return True
        if s in {"0", "false", "f", "no", "n"}:
            return False
        # Fallback: let pydantic try; if it fails, default True
        try:
            return bool(int(s))
        except Exception:
            return True

    @field_validator("qwen_gpu_max_gb", "qwen_cpu_max_gb", mode="before")
    @classmethod
    def _parse_floatish(cls, v):
        if v is None or isinstance(v, (int, float)):
            return v
        s = str(v).strip()
        if not s:
            return None
        try:
            return float(s)
        except Exception:
            return None  # fail-soft: treat as unset
            
    @field_validator("qwen_model_name", mode="before")
    @classmethod
    def _fallback_model_name(cls, v):
        if v:
            return v
        alt = os.getenv("QWEN_MODEL_ID")
        return alt or "Qwen/Qwen2.5-VL-3B-Instruct"

    @field_validator("qwen_device_map", mode="before")
    @classmethod
    def _fallback_device_map(cls, v):
        if v:
            return v
        alt = os.getenv("QWEN_DEVICE")
        return alt or "auto"

    @field_validator("qwen_torch_dtype", mode="before")
    @classmethod
    def _fallback_dtype(cls, v):
        if v:
            return v
        alt = os.getenv("QWEN_DTYPE")
        # allow "auto" to become None
        return None if (alt and alt.lower() == "auto") else alt

    # --- Back-compat property shims (do not remove until all callsites are updated) ---
    # Back-compat: used by health.py

            
    @property
    def google_cse_id(self) -> Optional[str]:
        """Legacy single-ID accessor; maps to text CSE ID if present."""
        return self.google_text_cse_id
    
    @property
    def vlm_model_name(self) -> str:
        # Map to Qwen model unless you introduce other VLMs later
        return self.qwen_model_name

    @property
    def qwen_model_id(self) -> str:
        """Legacy name used by qwen_captioner/health; map to qwen_model_name."""
        return self.qwen_model_name

    @property
    def qwen_dtype(self) -> Optional[str]:
        """Legacy short name; map to qwen_torch_dtype string ('bf16'|'fp16'|'fp32'|None)."""
        return self.qwen_torch_dtype

    @property
    def qwen_device(self) -> str:
        """Legacy device name; map to qwen_device_map."""
        return self.qwen_device_map

    @property
    def qwen_max_memory_resolved(self) -> Optional[Dict[str, str]]:
        """
        Build an accelerate-style max_memory mapping from gpu/cpu GiB values
        when qwen_max_memory isn't explicitly provided.
        """
        if self.qwen_max_memory:
            return self.qwen_max_memory
        mm: Dict[str, str] = {}
        if self.qwen_gpu_max_gb is not None:
            # single GPU id '0' is common; adjust if you multi-GPU later
            mm["0"] = f"{int(self.qwen_gpu_max_gb)}GiB"
        if self.qwen_cpu_max_gb is not None:
            mm["cpu"] = f"{int(self.qwen_cpu_max_gb)}GiB"
        return mm or None
    
    @property
    def qwen_max_memory_or_built(self) -> Optional[Dict[str, str]]:
        return self.qwen_max_memory_resolved
    
    # ---------- Validators for list-like envs ----------

    @field_validator(
        "allowed_pdf_roots",
        "cors_allow_origins",
        "whitelist_domains",
        "api_keys",
        mode="before",
    )
    @classmethod
    def _parse_list_env(cls, v):
        # Accept JSON list or comma-separated string; pass lists through
        if isinstance(v, list) or v is None:
            return v or []
        if isinstance(v, str):
            v = v.strip()
            if not v:
                return []
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return [str(x).strip() for x in parsed]
            except Exception:
                pass
            return [s.strip() for s in v.split(",") if s.strip()]
        return []

    @field_validator("verbosity", mode="before")
    @classmethod
    def _norm_verbosity(cls, v):
        if not v:
            return "normal"
        s = str(v).lower().strip()
        return s if s in ("brief", "normal", "detailed") else "normal"

    # ---------- Helpers ----------
    def resolved_allowed_roots(self) -> List[str]:
        """
        Combine roots in a stable, duplicate-free order for path guards.
        """
        roots: List[str] = []
        for p in [self.pdf_dir, self.corpus_dir, self.data_dir, *self.allowed_pdf_roots]:
            if p and p not in roots:
                roots.append(p)
        return roots

    # Back-compat alias: old code may reference settings.embed_model_name
    @property
    def embed_model_name(self) -> str:
        return self.text_embed_model_name

# Singleton instance
settings = Settings()

# If allowed_domains not explicitly given, mirror whitelist_domains (lowercased)
if not settings.allowed_domains:
    settings.allowed_domains = [d.lower() for d in (settings.whitelist_domains or [])]
    
# ---- Back-compat post-init shims ----
raw_domains = os.getenv("WHITELIST_DOMAINS")
if raw_domains:
    try:
        parsed = json.loads(raw_domains)
        if isinstance(parsed, list):
            settings.allowed_domains = [str(d).strip().lower() for d in parsed]
        else:
            settings.allowed_domains = [s.strip().lower() for s in raw_domains.split(",") if s.strip()]
    except Exception:
        settings.allowed_domains = [s.strip().lower() for s in raw_domains.split(",") if s.strip()]
else:
    # Default to whitelist_domains
    settings.allowed_domains = [d.lower() for d in (settings.whitelist_domains or [])]

if not settings.allowed_repos:
    settings.allowed_repos = []
