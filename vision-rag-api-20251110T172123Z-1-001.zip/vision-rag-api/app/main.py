"""
Purpose:
- FastAPI application factory and router mounts.
- Adds CORS for local dev + future domain.
- Uvicorn will serve this on 0.0.0.0:8000 by default.
"""

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from .core.settings import settings
from .api.health import router as health_router
from .api.rag import router as rag_router
from .api.vlm import router as vlm_router
from .api.search import router as search_router
from .api.images import router as pages_router
from .api.image_search import router as image_rag_router
from .api.fusion import router as fusion_router
from app.api.sources import router as sources_router
from app.api.dialog import router as dialog_router
from fastapi.middleware.cors import CORSMiddleware
from app.security.auth import require_api_key, ratelimit_dependency
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

def create_app() -> FastAPI:
    app = FastAPI(title="Vision-RAG API", version="0.1.0")
    app.add_middleware(ProxyHeadersMiddleware, trusted_hosts="*")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # CORS (tighten when public)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allow_origins or ["*"],  # dev fallback
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Global dependencies (applies to ALL routes). For staged rollout, you can
    # instead add these per-router: app.include_router(router, dependencies=[...])
    app.dependency_overrides = getattr(app, "dependency_overrides", {})
    
    # Safety: only enforce when keys are configured
    if settings.api_keys:
        app.router.dependencies.append(Depends(require_api_key))
        
    # Rate limit (always on)
    app.router.dependencies.append(Depends(ratelimit_dependency()))
    
    # Lightweight routes ready
    app.include_router(health_router)
    app.include_router(rag_router)
    app.include_router(vlm_router)
    app.include_router(pages_router)
    app.include_router(search_router)
    app.include_router(image_rag_router)
    app.include_router(fusion_router)
    app.include_router(sources_router, prefix="/api/v1/rag/pages", tags=["pages"])
    app.include_router(dialog_router,  prefix="/api/v1/dialog",     tags=["dialog"])
    return app

    

app = create_app()


