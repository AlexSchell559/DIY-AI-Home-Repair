# app/security/auth.py
from __future__ import annotations
import time, threading
from typing import Optional, Tuple
from fastapi import Header, HTTPException, status, Request
from ..core.settings import settings

# ---- Simple API key check ----
def require_api_key(x_api_key: Optional[str] = Header(default=None)):
    if not settings.api_keys:
        # If unset, allow (dev mode); flip to deny if you want strict by default
        return True
    if not x_api_key or x_api_key not in settings.api_keys:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing or invalid API key")
    return True

# ---- In-memory token bucket per (key or ip) ----
# Key: provided API key; else remote ip
_BUCKETS = {}
_LOCK = threading.Lock()

def _bucket_id(request: Request, x_api_key: Optional[str]) -> str:
    return x_api_key or request.client.host or "unknown"

def ratelimit_dependency(rps: float = None, burst: int = None):
    rps = rps if rps is not None else settings.rate_limit_rps
    burst = burst if burst is not None else settings.rate_limit_burst

    def _dep(request: Request, x_api_key: Optional[str] = Header(default=None)):
        now = time.monotonic()
        bid = _bucket_id(request, x_api_key)
        with _LOCK:
            tokens, last = _BUCKETS.get(bid, (burst, now))
            # refill
            tokens = min(burst, tokens + (now - last) * rps)
            if tokens < 1.0:
                # no tokens -> 429
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            tokens -= 1.0
            _BUCKETS[bid] = (tokens, now)
        return True
    return _dep

