package com.diy_ai.homerepairbot
// LlmModels.kt

data class LlmRequest(
    // The text prompt (your description)
    val inputs: String,
    // Parameters for the model (e.g., max tokens, temperature)
    val parameters: Map<String, Any> = mapOf(
        "max_new_tokens" to 256,
        "temperature" to 0.7
    )
)

data class LlmResponse(
    // Hugging Face API response often returns a list
    val generated_text: String
)

data class LlmMultiModalRequest(
    // For multimodal, the input is often a string containing the text and the image reference
    val inputs: String,
    val parameters: Map<String, Any> = mapOf(
        "max_new_tokens" to 512,
        "temperature" to 0.7
    )
    // NOTE: Qwen2.5-VL usually requires the image to be embedded in the prompt string
    // or requires a specialized payload structure. We'll use a Base64 string in the prompt
    // for simplicity, or assume a Hugging Face Inference Endpoint structure.
)
