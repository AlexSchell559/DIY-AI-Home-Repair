package com.diy_ai.homerepairbot.util

import android.content.Context
import org.json.JSONArray

/**
 * Very simple local persistence for recent dialog_ids.
 * Stored as a JSON array in SharedPreferences.
 */
class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("sessions", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LIST = "dialog_ids"
        private const val MAX_ITEMS = 25
        const val NEW_SESSION_LABEL = "New Session"
    }

    fun getAll(): List<String> {
        val raw = prefs.getString(KEY_LIST, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrElse { emptyList() }
    }

    fun add(dialogId: String) {
        val list = getAll().toMutableList()
        // Move to front if exists, else add to front
        list.remove(dialogId)
        list.add(0, dialogId)
        while (list.size > MAX_ITEMS) list.removeLast()

        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(KEY_LIST, arr.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_LIST).apply()
    }
}
