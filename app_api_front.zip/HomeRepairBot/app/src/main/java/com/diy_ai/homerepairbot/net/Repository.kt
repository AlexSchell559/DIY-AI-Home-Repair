package com.diy_ai.homerepairbot.net

import com.google.gson.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MultipartBody
import retrofit2.HttpException


// Small app-visible error type for nice toasts/snackbars
class FriendlyException(message: String) : Exception(message)

class Repository(
    private val api: ManbproApi = ApiConfig.retrofit().create(ManbproApi::class.java)
) {
    suspend fun healthz() = api.healthz()

    /**
     * Unified submit that returns a Result<JsonObject> so callers can do
     * .onSuccess/.onFailure. Uses the RAW endpoint to keep payload flexible.
     * imagePart = null -> text-only
     */
    suspend fun submitFusion(
        text: String,
        dialogId: String,
        imagePart: MultipartBody.Part? = null
    ): Result<JsonObject> = runCatching {
        val textPart = text.toRequestBody("text/plain".toMediaType())
        val dialogIdPart = dialogId.toRequestBody("text/plain".toMediaType())
        val intentGatePart = "1".toRequestBody("text/plain".toMediaType())
        val ackStagePart = "2".toRequestBody("text/plain".toMediaType())

        // Use the RAW JSON variant so UI can read intent_decision/results directly
        api.fusionRaw(
            image = imagePart,
            text = textPart,
            dialogId = dialogIdPart,
            intentGate = intentGatePart,
            ackStage = ackStagePart
        )
    }.recoverCatching { e ->
        if (e is HttpException) {
            when (e.code()) {
                413 -> throw FriendlyException("Your image is too large. I’ll compress and retry.")
                429 -> throw FriendlyException("I’m being rate-limited. Retrying shortly…")
            }
        }
        throw e
    }

    // ---- Existing helpers (kept as-is; useful for callers that want typed response) ----

    suspend fun fusionTextOnly(
        text: String,
        dialogId: String,
        ackStage: Int = 0
    ): FusionResponse {
        val textPart = text.toRequestBody("text/plain".toMediaType())
        val dialogIdPart = dialogId.toRequestBody("text/plain".toMediaType())
        val intentGatePart = "1".toRequestBody("text/plain".toMediaType())
        val ackStagePart = ackStage.toString().toRequestBody("text/plain".toMediaType())
        return api.fusion(
            image = null,
            text = textPart,
            dialogId = dialogIdPart,
            intentGate = intentGatePart,
            ackStage = ackStagePart
        )
    }

    suspend fun fusionTextOnlyRaw(text: String, dialogId: String): JsonObject {
        val textPart = text.toRequestBody("text/plain".toMediaType())
        val dialogIdPart = dialogId.toRequestBody("text/plain".toMediaType())
        val intentGatePart = "1".toRequestBody("text/plain".toMediaType())
        val ackStagePart = "2".toRequestBody("text/plain".toMediaType())
        return api.fusionRaw(
            image = null,
            text = textPart,
            dialogId = dialogIdPart,
            intentGate = intentGatePart,
            ackStage = ackStagePart
        )
    }

    suspend fun fusionWithImage(
        text: String,
        dialogId: String,
        imagePart: MultipartBody.Part,
        ackStage: Int = 0
    ): FusionResponse {
        val textPart = text.toRequestBody("text/plain".toMediaType())
        val dialogIdPart = dialogId.toRequestBody("text/plain".toMediaType())
        val intentGatePart = "1".toRequestBody("text/plain".toMediaType())
        val ackStagePart = ackStage.toString().toRequestBody("text/plain".toMediaType())
        return api.fusion(
            image = imagePart,
            text = textPart,
            dialogId = dialogIdPart,
            intentGate = intentGatePart,
            ackStage = ackStagePart
        )
    }

    suspend fun getDialogState(dialogId: String): JsonObject = api.dialogState(dialogId)
}
