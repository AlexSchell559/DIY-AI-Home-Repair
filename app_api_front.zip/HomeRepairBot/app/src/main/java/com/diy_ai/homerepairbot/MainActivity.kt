package com.diy_ai.homerepairbot

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.diy_ai.homerepairbot.databinding.ActivityMainBinding
import com.diy_ai.homerepairbot.net.ApiConfig
import com.diy_ai.homerepairbot.net.ManbproApi
import com.diy_ai.homerepairbot.net.Repository
import com.diy_ai.homerepairbot.util.SessionStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.RequestBody.Companion.toRequestBody
import androidx.core.graphics.scale
import okhttp3.MediaType.Companion.toMediaType
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import java.util.UUID
import androidx.appcompat.app.AlertDialog
import com.diy_ai.homerepairbot.net.FusionResponse
import com.diy_ai.homerepairbot.net.FusionResultItem
import com.diy_ai.homerepairbot.net.messagesAsStrings

class MainActivity : AppCompatActivity() {

    // --- ViewBinding & simple UI state ---
    private lateinit var binding: ActivityMainBinding

    private lateinit var sessionStore: SessionStore

    private var currentImageUri: Uri? = null
    private var currentDialogId: String = "dlg-android-001"

    private var currentImageBitmap: android.graphics.Bitmap? = null

    // ---- image helpers (safe, OOM-resistant) ----
    private val maxUploadBytes: Int = 45 * 1024 * 1024 // 45 MB client cap
    private val maxDimension: Int = 2560                      // downscale ceiling per side

    // Gallery picker (returns a content Uri)
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            currentImageUri = it
            binding.imageViewPhoto.setImageURI(it)
        }
    }

    // Camera preview bitmap (kept simple for now—Step 7 will do real file capture)
    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        bitmap?.let {
            currentImageBitmap = it        // keep a reference
            binding.imageViewPhoto.setImageBitmap(it)
        }
    }

    // Runtime permission prompt
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(
            this,
            if (granted) getString(R.string.permission_granted) else getString(R.string.permission_denied),
            Toast.LENGTH_SHORT
        ).show()
    }
    private val gsonPretty by lazy { GsonBuilder().setPrettyPrinting().create() }
    private fun pretty(obj: JsonObject?) =
        if (obj == null) "(no server state)" else gsonPretty.toJson(obj)

    // remember what we just tried so we can resubmit on ack
    private var lastDescription: String = ""
    private var lastUsedImage: Boolean = false


    private fun onDialogChosen(chosen: String) {
        if (chosen == SessionStore.NEW_SESSION_LABEL) {
            currentDialogId = "dlg-" + UUID.randomUUID().toString().take(8)
            // fresh slate UI
            binding.textViewResponse.text = ""
            binding.textLastPrompt.text = ""
            binding.inputDescription.setText("")
            currentImageUri = null
            currentImageBitmap = null
            binding.imageViewPhoto.setImageDrawable(null)
            binding.imageLastSubmitted.setImageDrawable(null)
            binding.imageLastSubmitted.visibility = View.GONE
            return
        }

        // Existing session: load server state
        currentDialogId = chosen
        binding.textViewResponse.text = getString(R.string.loading_session, chosen)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val state = Repository().getDialogState(chosen)
                withContext(Dispatchers.Main) {
                    // Best-effort: surface a prior prompt if present
                    val lastQuery = state.get("last_query")?.asString ?: ""
                    if (lastQuery.isNotBlank()) binding.textLastPrompt.text = lastQuery

                    binding.textViewResponse.text = pretty(state)

                    // Clear current inputs to prevent cross-talk
                    binding.inputDescription.setText("")
                    currentImageUri = null
                    currentImageBitmap = null
                    binding.imageViewPhoto.setImageDrawable(null)
                    binding.imageLastSubmitted.setImageDrawable(null)
                    binding.imageLastSubmitted.visibility = View.GONE
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.textViewResponse.text =
                        getString(R.string.fusion_error, "load state: ${e.message}")
                }
            }
        }
    }

    // ---------------- Lifecycle ----------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Make OUTPUT and INPUT scrollable (independent of any ScrollView in XML)
        binding.textViewResponse.movementMethod = ScrollingMovementMethod()
        binding.textViewResponse.isVerticalScrollBarEnabled = true

        binding.inputDescription.isVerticalScrollBarEnabled = true
        binding.inputDescription.setHorizontallyScrolling(false) // wraps lines
        binding.inputDescription.maxLines = 6
        sessionStore = SessionStore(this)

        initDialogSpinner()
        initButtons()
    }

    // ---------------- UI setup helpers ----------------

    /**
     * Initializes the dialog/session selector.
     * For now: a small in-memory list; we’ll persist later.
     */
    private fun initDialogSpinner() {
        refreshDialogSpinner(preserveSelection = false)
        val recent: List<String> = sessionStore.getAll()
        val items: MutableList<String> = mutableListOf(SessionStore.NEW_SESSION_LABEL).apply {
            addAll(recent)
        }
        binding.spinnerDialogs.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val chosen: String = parent.getItemAtPosition(position) as String
                    onDialogChosen(chosen)
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
            }

    }

    private fun showAckDialog(stage: Int, total: Int, message: String, onAck: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.safety_ack_title, stage + 1, total))
            .setMessage(message.ifBlank { getString(R.string.safety_ack_default) })
            .setPositiveButton(R.string.safety_ack_continue) { _, _ -> onAck() }
            .setNegativeButton(R.string.safety_ack_cancel, null)
            .show()
    }


    /**
     * Wire buttons: camera, gallery, send (fusion text-only), and Check API.
     */
    private fun initButtons() {
        // Camera
        binding.buttonCamera.setOnClickListener {
            launchCameraWithPermission()
        }

    // Gallery (no runtime permission needed on modern Android if using GetContent)
        binding.buttonGallery.setOnClickListener {
            galleryLauncher.launch("image/*")
        }


        // Check API -> GET /healthz
        binding.buttonCheckApi.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val api = ApiConfig.retrofit().create(ManbproApi::class.java)
                    val res = api.healthz()
                    val msg = res.toString().take(160)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MainActivity,
                            getString(R.string.healthz_ok, msg),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MainActivity,
                            getString(R.string.healthz_error, e.message ?: "unknown"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
        // Long-press Check API to fetch server dialog state for the current dialog_id
        binding.buttonCheckApi.setOnLongClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val repo = Repository()
                    val state = repo.getDialogState(currentDialogId)  // GET /api/v1/dialog/state
                    withContext(Dispatchers.Main) {
                        // Show a short preview at top of the output card
                        binding.textLastPrompt.text = getString(R.string.dialog_state_for, currentDialogId)
                        binding.textViewResponse.text = state.toString().take(1500)
                        binding.textViewResponse.scrollTo(0, 0)
                        Toast.makeText(this@MainActivity, getString(R.string.dialog_state_loaded), Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "Dialog state error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            true
        }

        // Clear output
        binding.buttonClear.setOnClickListener {
            // Output
            binding.textViewResponse.text = ""
            binding.textLastPrompt.text = ""

            // Input text
            binding.inputDescription.setText("")

            // Images (preview + last submitted) and refs
            currentImageUri = null
            currentImageBitmap = null
            binding.imageViewPhoto.setImageDrawable(null)
            binding.imageLastSubmitted.setImageDrawable(null)
            binding.imageLastSubmitted.visibility = View.GONE
        }


        // Send → Fusion (text-only)
        binding.buttonSend.setOnClickListener {
            val description = binding.inputDescription.text?.toString().orEmpty()
            if (description.isBlank()) {
                Toast.makeText(this, getString(R.string.describe_issue_hint), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Echo prompt and (if present) thumbnail into the output card
            binding.textLastPrompt.text = description
            currentImageUri?.let {
                binding.imageLastSubmitted.setImageURI(it)
                binding.imageLastSubmitted.visibility = View.VISIBLE
            } ?: currentImageBitmap?.let {
                binding.imageLastSubmitted.setImageBitmap(it)
                binding.imageLastSubmitted.visibility = View.VISIBLE
            } ?: run {
                binding.imageLastSubmitted.visibility = View.GONE
            }
            binding.textViewResponse.text = getString(R.string.submitting_rag)
            // Echo prompt + thumbnail (your existing code above this stays)
            lastDescription = description
            lastUsedImage = (currentImageUri != null || currentImageBitmap != null)

            CoroutineScope(Dispatchers.IO).launch {
                val repo = Repository()
                var currentAck = 0

                suspend fun doSubmit(ackStage: Int): FusionResponse {
                    val maybePart: okhttp3.MultipartBody.Part? = buildJpegPartFromSelection()
                    return if (maybePart != null) {
                        repo.fusionWithImage(lastDescription, currentDialogId, maybePart, ackStage)
                    } else {
                        repo.fusionTextOnly(lastDescription, currentDialogId, ackStage)
                    }
                }

                while (true) {
                    val response: FusionResponse = doSubmit(currentAck)

                    val decision: String = response.intentDecision?.decision ?: "proceed"
                    val ackStageFromServer: Int = response.intentDecision?.ackStage ?: 0
                    val staged: List<String> =
                        response.intentDecision?.messagesAsStrings().orEmpty()
                    val total: Int = if (staged.isNotEmpty()) staged.size else 2

                    if (decision == "ack_required") {
                        val msgToShow: String = staged.getOrNull(ackStageFromServer)
                            ?: staged.lastOrNull()
                            ?: getString(R.string.safety_ack_default)

                        withContext(Dispatchers.Main) {
                            showAckDialog(ackStageFromServer, total, msgToShow) {
                                CoroutineScope(Dispatchers.IO).launch {
                                    currentAck = ackStageFromServer  // acknowledge this stage
                                }
                            }
                        }
                        // wait for user tap to bump currentAck
                        val target = ackStageFromServer
                        while (currentAck == target) {
                            kotlinx.coroutines.delay(50)
                        }
                        continue
                    }

                    // proceed → render results
                    val top: List<FusionResultItem> = response.results?.take(3).orEmpty()
                    val niceList: String = buildString {
                        if (top.isEmpty()) {
                            appendLine(getString(R.string.no_results))
                        } else {
                            top.forEachIndexed { idx: Int, item: FusionResultItem ->
                                appendLine("${idx + 1}. ${item.title ?: "(no title)"}")
                                item.snippet?.let { appendLine(it) }
                                item.url?.let { appendLine(it) }
                                appendLine()
                            }
                        }
                    }

                    withContext(Dispatchers.Main) {
                        binding.textViewResponse.text = buildString {
                            appendLine("Decision: $decision  (ok=${response.ok}, ack_stage=${response.intentDecision?.ackStage ?: "?"})")
                            appendLine("Dialog: ${response.dialogId ?: currentDialogId}")
                            appendLine()
                            append(niceList)
                        }
                        binding.textViewResponse.scrollTo(0, 0)
                        sessionStore.add(currentDialogId)
                        refreshDialogSpinner()
                    }
                    break
                }
            }
        }
    }



    private fun buildJpegPartFromSelection(): okhttp3.MultipartBody.Part? {
        // Prefer a gallery Uri; otherwise use the camera preview bitmap
        currentImageUri?.let { uri -> return buildJpegPartFromUri(uri, "photo.jpg") }
        currentImageBitmap?.let { bmp -> return buildJpegPartFromBitmap(bmp, "camera.jpg") }
        return null
    }

    private fun buildJpegPartFromUri(uri: Uri, filename: String): okhttp3.MultipartBody.Part? {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                // Read the full stream once (content:// safe), then decode with bounds/scaling
                val data = input.readBytes()

                // Bounds pass
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size, bounds)

                // Compute sample size to keep max side <= MAX_DIMENSION
                val sample = computeInSampleSize(bounds.outWidth, bounds.outHeight, maxDimension)

                // Decode scaled bitmap
                val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size, opts) ?: return null

                // Compress under 45 MB (quality ladder + optional half-scale)
                val payload = compressToCap(bmp) ?: return null
                val req = payload.toRequestBody("image/jpeg".toMediaType())
                okhttp3.MultipartBody.Part.createFormData("image", filename, req)
            }
        } catch (_: Throwable) { null }
    }

    private fun buildJpegPartFromBitmap(src: android.graphics.Bitmap, filename: String): okhttp3.MultipartBody.Part? {
        return try {
            val scaled = downscaleIfNeeded(src, maxDimension)
            val payload = compressToCap(scaled) ?: return null
            val req = payload.toRequestBody("image/jpeg".toMediaType())
            okhttp3.MultipartBody.Part.createFormData("image", filename, req)
        } catch (_: Throwable) { null }
    }

    private fun computeInSampleSize(w: Int, h: Int, maxDim: Int): Int {
        var inSampleSize = 1
        var width = w
        var height = h
        while (width > maxDim || height > maxDim) {
            width /= 2; height /= 2; inSampleSize *= 2
        }
        return if (inSampleSize < 1) 1 else inSampleSize
    }

    private fun downscaleIfNeeded(src: android.graphics.Bitmap, maxDim: Int): android.graphics.Bitmap {
        val w = src.width; val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val scale = if (w >= h) maxDim / w.toFloat() else maxDim / h.toFloat()
        val nw = (w * scale).toInt().coerceAtLeast(1)
        val nh = (h * scale).toInt().coerceAtLeast(1)
        return src.scale(nw, nh)
    }

    private fun compressToCap(bitmap: android.graphics.Bitmap): ByteArray? {
        // Try quality ladder, then one more half-scale if needed
        val qualities = listOf(90, 80, 70, 60, 50, 40, 30)
        for (q in qualities) {
            val baos = java.io.ByteArrayOutputStream()
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, q, baos)
            val arr = baos.toByteArray()
            if (arr.size <= maxUploadBytes) return arr
        }
        val half = bitmap.scale(bitmap.width / 2, bitmap.height / 2)
        val baos = java.io.ByteArrayOutputStream()
        half.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, baos)
        val downsized = baos.toByteArray()
        return if (downsized.size <= maxUploadBytes) downsized else null
    }

    private fun refreshDialogSpinner(preserveSelection: Boolean = true) {
        val recent = sessionStore.getAll()
        val items = mutableListOf(SessionStore.NEW_SESSION_LABEL)
        items.addAll(recent)

        val prev = if (preserveSelection) binding.spinnerDialogs.selectedItem?.toString() else null

        val adapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            items
        )
        binding.spinnerDialogs.adapter = adapter

        // restore selection if possible
        val target = prev ?: items.firstOrNull()
        val idx = items.indexOfFirst { it == target }
        if (idx >= 0) binding.spinnerDialogs.setSelection(idx)
    }

    // OkHttp modern extensions
    // private fun String.toMediaType() = okhttp3.MediaType.Companion.toMediaType()
    // private fun ByteArray.toRequestBody(mt: okhttp3.MediaType) =
    //     okhttp3.RequestBody.Companion.toRequestBody(this, mt)

    // ---------------- Utilities ----------------

    private fun launchCameraWithPermission() {
        val perm = Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch(null)
        } else {
            requestPermissionLauncher.launch(perm)
        }
    }

}
