package com.diy_ai.homerepairbot.net

import com.google.gson.JsonObject

import com.google.gson.annotations.SerializedName
// ADD this import at the top
import com.google.gson.JsonElement

// Health can vary; be flexible
typealias HealthzResponse = JsonObject

data class FusionIntentDecision(
    @SerializedName("decision") val decision: String? = null,
    @SerializedName("ack_stage") val ackStage: Int? = null,
    @SerializedName("staged_messages") val stagedMessages: List<JsonElement>? = null
)

data class FusionResultItem(
    @SerializedName("type") val type: String? = null,
    @SerializedName("score") val score: Double? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("url") val url: String? = null,
    @SerializedName("snippet") val snippet: String? = null
)

data class FusionResponse(
    @SerializedName("schema_version") val schemaVersion: String? = null,
    @SerializedName("ok") val ok: Boolean? = null,
    @SerializedName("intent_decision") val intentDecision: FusionIntentDecision? = null,
    @SerializedName("safety") val safety: Map<String, Any>? = null,
    @SerializedName("results") val results: List<FusionResultItem>? = null,
    @SerializedName("dialog_id") val dialogId: String? = null
)

fun FusionIntentDecision?.messagesAsStrings(): List<String> {
    this ?: return emptyList()
    return (stagedMessages ?: emptyList()).mapNotNull { el ->
        when {
            el.isJsonPrimitive -> el.asJsonPrimitive.asString
            el.isJsonObject -> el.asJsonObject["text"]?.asString
                ?: el.asJsonObject["message"]?.asString
                ?: el.asJsonObject.toString()
            else -> el.toString()
        }
    }
}
