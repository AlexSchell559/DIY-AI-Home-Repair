package com.diy_ai.homerepairbot.net

import okhttp3.Interceptor
import okhttp3.Response
import kotlin.math.min
import kotlin.random.Random

class Retry429Interceptor(private val maxRetries: Int = 3) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        var tryCount = 0
        var response = chain.proceed(chain.request())

        while (response.code == 429 && tryCount < maxRetries) {
            val retryAfter = response.headers["Retry-After"]?.toLongOrNull()
            val baseDelayMs = if (retryAfter != null) retryAfter * 1000 else (250L shl tryCount)
            val jitter = Random.nextLong(0, 150)
            response.close()
            Thread.sleep(min(baseDelayMs + jitter, 2000L))
            tryCount++
            response = chain.proceed(chain.request())
        }
        return response
    }
}
