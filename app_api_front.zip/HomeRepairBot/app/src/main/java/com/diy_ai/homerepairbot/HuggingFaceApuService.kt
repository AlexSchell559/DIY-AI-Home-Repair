package com.diy_ai.homerepairbot

// HuggingFaceApiService.kt
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface HuggingFaceApiService {
    @POST("/models/{modelName}")
    suspend fun generateContent(
        @Header("Authorization") token: String,
        @retrofit2.http.Path("modelName") modelName: String,
        @Body request: LlmMultiModalRequest
    ): List<LlmResponse>
}