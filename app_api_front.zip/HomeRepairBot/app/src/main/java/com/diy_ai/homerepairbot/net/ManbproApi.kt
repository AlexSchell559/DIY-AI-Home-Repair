@file:Suppress("SpellCheckingInspection")

package com.diy_ai.homerepairbot.net

import com.google.gson.JsonObject
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ManbproApi {

    @GET("/healthz")
    suspend fun healthz(): HealthzResponse

    @Multipart
    @POST("/api/v1/rag/fusion/search")
    suspend fun fusion(
        @Part image: MultipartBody.Part?,
        @Part("text") text: RequestBody?,
        @Part("dialog_id") dialogId: RequestBody,
        @Part("intent_gate") intentGate: RequestBody,
        @Part("ack_stage") ackStage: RequestBody,
        @Part("room") room: RequestBody? = null,
        @Part("material") material: RequestBody? = null,
        @Part("component") component: RequestBody? = null,
        @Part("tool") tool: RequestBody? = null
    ): FusionResponse

    // Raw fusion for diagnostics (returns the original JSON object)
    @Multipart
    @POST("/api/v1/rag/fusion/search")
    suspend fun fusionRaw(
        @Part image: MultipartBody.Part? = null,
        @Part("text") text: RequestBody?,
        @Part("dialog_id") dialogId: RequestBody,
        @Part("intent_gate") intentGate: RequestBody,
        @Part("ack_stage") ackStage: RequestBody,
        @Part("room") room: RequestBody? = null,
        @Part("material") material: RequestBody? = null,
        @Part("component") component: RequestBody? = null,
        @Part("tool") tool: RequestBody? = null
    ): JsonObject

    @GET("/api/v1/dialog/state")
    suspend fun dialogState(@Query("dialog_id") dialogId: String): JsonObject

    @Streaming
    @GET("/api/v1/rag/pages/get-image")
    suspend fun pageImage(
        @Query("doc_hash") docHash: String,
        @Query("page") page: Int
    ): Response<ResponseBody>
}

